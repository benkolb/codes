
% Application example for my SVAR toolbox
% Benedikt Kolb, Feb. 2015

clear all; clc; close all;
Y = csvread('example_data.csv',1,1);
Y(:,1) = log(Y(:,1)); % take log of GDP
determ = 2; % deterministic regressors: constant + (linear) time trend

%% Choose lags according to Bayesian info criterion
[~,~,qBIC,~,~] = lagselect(Y,12,determ,0); % max. lags: 12, no result table

%% Run VAR regression
VAR = VARreg(Y,qBIC,determ);

%% Get IRFs and conf. intervals for short-run restrictions
[IRF, invA, IRF_opt]   = VARImpResp(VAR,40);
ndraws = 200; conf_level = 90;
[LO,HI,ME] = VARConfInt(VAR,IRF_opt,ndraws,conf_level);

%% Plot IRFs
[t, s, v] = size(IRF);
nams = {'GDP shock','defl. shock','hours shock'}; 
namv = {'(log) real GDP','GDP deflator','hours'};
row = round(sqrt(VAR.nvar));
col = ceil(sqrt(VAR.nvar));
steps = 1:1:size(IRF,1);

for jj=1:s
    figure('name',strcat('shock_No_',num2str(jj)))
    for ii=1:v
        subplot(row,col,ii);
        plot(steps,ME(:,ii,jj),'b','LineWidth',2); hold on;
        plot(steps,LO(:,ii,jj),'k--',steps,HI(:,ii,jj),'k--');
        xlabel(namv{ii});
    end
    suptitle(nams{jj})
end
