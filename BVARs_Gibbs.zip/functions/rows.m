function out=rows(x)
out=size(x,1);