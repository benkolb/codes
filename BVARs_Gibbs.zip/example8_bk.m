clear
addpath('functions');
data=xlsread('\data\datain.xls'); %data for US GDP growth and inflation 1948q1 2010q4
N=cols(data);
horizon=3;
path=[1;1;1]; %constrained values for X
L=2; %lag length of the VAR
Y=data;
%take lags
X=[];
for j=1:L
    X=[X lag0(data,j) ];
end
X=[X ones(rows(X),1)];
Y=Y(L+1:end,:);
X=X(L+1:end,:);
T=rows(X);
B=X\Y; %ols estimate
res=Y-X*B;
sigma=(res'*res)/T;
A0=chol(sigma);
%calculate impulse responses to be used to construct R
S=zeros(1,N);
S(1)=1; %shock to first eq
Z1=irfsim(B,N,L,A0,S,horizon+L);
S=zeros(1,N);
S(2)=1; %shock to 2nd eq
Z2=irfsim(B,N,L,A0,S,horizon+L);
%calculate unconditional forecast to be used to construct R
yhat1=zeros(horizon+L,N);
yhat1(1:L,:)=Y(end-L+1:end,:);
for i=L+1:horizon+L
    x=[];
    for j=1:L
        x=[x yhat1(i-j,:)];
    end
    yhat1(i,:)=[x 1]*B;
end
yhat1=yhat1(L+1:end,:);
%construct the R matrix
R= [Z1(1,2) Z2(1,2) 0       0       0       0;
    Z1(2,2) Z2(2,2) Z1(1,2) Z2(1,2) 0       0;
    Z1(3,2) Z2(3,2) Z1(2,2) Z2(2,2) Z1(1,2) Z2(1,2)];
%construct the r matrix
r=path -yhat1(:,2);
%compute the restricted structural shocks
ehat=R'*pinv(R*R')*r;
ehat=reshape(ehat,N,horizon)';
%compute the conditional forecast
yhat2=zeros(horizon+L,N);
yhat2(1:L,:)=Y(end-L+1:end,:);
for i=L+1:horizon+L
    x=[];
    for j=1:L
        x=[x yhat2(i-j,:)];
    end
    yhat2(i,:)=[x 1]*B+ehat(i-L,:)*A0;
end
yhat2=yhat2(L+1:end,end);






