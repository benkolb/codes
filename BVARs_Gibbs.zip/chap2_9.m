
% Code to redo example 7.2 from chapter 2 in Blake/Mumtaz (BoE, 2014)
% Calculating the distribution of conditional forecasts
% by Benedikt Kolb, June 2016


%% Housekeeping
clear; close all;
rng(42);


%% set Gibbs sampler options and pre-allocate
ndraw = 2000; % # draws (after burn-in); default: 2000
nburn = 3000; % # burn-in draws; default: 3000
nrot  = 100;   % # rotations of A0 draw
ndet  = 1;     % # deterministic regressors
nlag  = 2;     % # lags
hor   = 3;     % hor for structural IRFs
fhor  = 3;    % forecast hor
% data-specific setting
pnam  = {'GDP Growth','Inflation'};
tim   = 1948.75:0.25:2011.75;
% IRF-specific settings
spos  = 1; % position of variable to be shocked (in [1, nvar])
shimp = 1; % shock impact (set to 1, -1, sigma, etc.)
path  = [1 1 1]'; % conditions imposed on forecast of X


%% Load data and create Y and X
dat       = xlsread('data\datain.xls');
Y         = dat(nlag+1:end,:);
[T, nvar] = size(Y);
X         = NaN(T,nvar*nlag+ndet);
X(:,end)  = ones(T,1);
for ll=1:nlag
    X(:,(ll-1)*nvar+1:ll*nvar) = dat(nlag+1-ll:end-ll,:);
end
nbet      = nlag*nvar + ndet; % # beta coeffs (fewer b/o dummies!)


%% Starting values
bOLS = X\Y;
res  = Y - X*bOLS;
Sig  = (res'*res)/T;
A0   = chol(Sig);


%% Construct matrix of linear restrictions, R, for cond. forecast
% impulse responses to first variable
e = zeros(fhor+nlag+nlag,nvar);
% choose shock here (first variable)
e(nlag+1,1) = 1;
y = zeros(fhor+nlag+nlag,nvar);
for k = nlag+1:fhor+nlag;
    x = NaN(1,nlag*nvar);
    for i = 1:nlag
        x((i-1)*nlag+1:i*nlag) = y(k-i,:);
    end
    y(k,:) = [x 1]*bOLS + e(k,:)*A0;
end
Z1 = y(nlag+1:size(y,1)-nlag,:);

% impulse responses to second variable
e = zeros(fhor+nlag+nlag,nvar);
% choose shock here (second variable)
e(nlag+1,2) = 1;
y = zeros(fhor+nlag+nlag,nvar);
for k = nlag+1:fhor+nlag;
    x = NaN(1,nlag*nvar);
    for i = 1:nlag
        x((i-1)*nlag+1:i*nlag) = y(k-i,:);
    end
    y(k,:) = [x 1]*bOLS + e(k,:)*A0;
end
Z2 = y(nlag+1:size(y,1)-nlag,:);

% unconditional forecast at end of data Y
uncondfc = zeros(fhor+nlag,nvar);
uncondfc(1:nlag,:) = Y(end-nlag+1:end,:);
for k = nlag+1:fhor+nlag
    x = NaN(1,nlag*nvar);
    for i = 1:nlag
        x((i-1)*nlag+1:i*nlag) = uncondfc(k-i,:);
    end
    uncondfc(k,:) = [x 1]*bOLS;
end
uncondfc = uncondfc(nlag+1:end,:);

% construct the R matrix
R = [Z1(1,2) Z2(1,2) 0       0       0       0;
    Z1(2,2) Z2(2,2) Z1(1,2) Z2(1,2) 0       0;
    Z1(3,2) Z2(3,2) Z1(2,2) Z2(2,2) Z1(1,2) Z2(1,2)];

% r matrix
r = path - uncondfc(:,2);

% restricted structural shocks - these guarantee that "path" holds!
ehat = R'*pinv(R*R')*r;
ehat = reshape(ehat,nvar,fhor)';

% conditional forecast
condfc = zeros(fhor+nlag,nvar);
condfc(1:nlag,:) = Y(end-nlag+1:end,:);
for k = nlag+1:fhor+nlag
    x = NaN(1,nlag*nvar);
    for i = 1:nlag
        x((i-1)*nlag+1:i*nlag) = condfc(k-i,:);
    end
    condfc(k,:) = [x 1]*bOLS + ehat(k-nlag,:)*A0;
end
condfc=condfc(nlag+1:end,:);

% initialise conditional forecast
cond_fore = condfc;


%% Preallocate arrays to save draws of interest
bdraw = NaN(ndraw, nbet);
fdraw = NaN(ndraw, fhor, nvar); % forecast
irfs  = NaN(ndraw, hor-nlag, nvar); % response to structural shock


% ii=1;
% break


%% Gibbs sampler
wb = waitbar(0,'Gibbs sampling...');

for ii = 1:nburn+ndraw
    
    %% Step 1: Draw VAR parameters and their covariance
    % a) append conditional forecast to data
    dats = [dat; cond_fore];
    Ys   = dats(nlag+1:end,:);
    Ts = size(Ys,1);
    Xs = NaN(Ts,nvar*nlag+ndet);
    Xs(:,end) = ones(Ts,1);
    for ll=1:nlag
        Xs(:,(ll-1)*nvar+1:ll*nvar) = dats(nlag+1-ll:end-ll,:);
    end
    % b) draw beta and Sigma
    M = reshape(Xs\Ys,nvar*(nvar*nlag+ndet),1);
    V = kron(Sig,eye(nvar*nlag+ndet)/(Xs'*Xs));
    b = M + (randn(1,nvar*(nvar*nlag+ndet))*chol(V))';
    bet = reshape(b,nvar*nlag+ndet,nvar);
    res = Y - X*bet;
    scl = res'*res;
    aux = NaN(Ts,length(scl));
    for iw = 1:Ts
        aux(iw,:) = (chol(eye(nvar)/scl)'*randn(length(scl),1))';
    end
    Sig = eye(nvar)/(aux'*aux);
    % c) calculate A0 matrix
    A0 = chol(Sig);
    
    %% Step 2: Construct the conditional forecast
    % impulse responses to first variable
    e = zeros(fhor+nlag+nlag,nvar);
    e(nlag+1,1) = 1;
    y = zeros(fhor+nlag+nlag,nvar);
    for k = nlag+1:fhor+nlag;
        x = NaN(1,nlag*nvar);
        for i = 1:nlag
            x((i-1)*nlag+1:i*nlag) = y(k-i,:);
        end
        y(k,:) = [x 1]*bet + e(k,:)*A0;
    end
    Z1 = y(nlag+1:size(y,1)-nlag,:);
    % impulse responses to second variable
    e = zeros(fhor+nlag+nlag,nvar);
    e(nlag+1,2) = 1;
    y = zeros(fhor+nlag+nlag,nvar);
    for k = nlag+1:fhor+nlag;
        x = NaN(1,nlag*nvar);
        for i = 1:nlag
            x((i-1)*nlag+1:i*nlag) = y(k-i,:);
        end
        y(k,:) = [x 1]*bet + e(k,:)*A0;
    end
    Z2 = y(nlag+1:size(y,1)-nlag,:);
    % unconditional forecast at end of data Y
    uncondfc = zeros(fhor+nlag,nvar);
    uncondfc(1:nlag,:) = Y(end-nlag+1:end,:);
    for k = nlag+1:fhor+nlag
        x = NaN(1,nlag*nvar);
        for i = 1:nlag
            x((i-1)*nlag+1:i*nlag) = uncondfc(k-i,:);
        end
        uncondfc(k,:) = [x 1]*bet;
    end
    uncondfc = uncondfc(nlag+1:end,:);
    
    % construct the R matrix
    R = [Z1(1,2) Z2(1,2) 0       0       0       0;
        Z1(2,2) Z2(2,2) Z1(1,2) Z2(1,2) 0       0;
        Z1(3,2) Z2(3,2) Z1(2,2) Z2(2,2) Z1(1,2) Z2(1,2)];
    
    % r matrix
    r = path - uncondfc(:,2);
    
    % draw (reduced-form) shocks s.t. "path" holds for current A0
    Mss = R'*pinv(R*R')*r;                  % mean of structural shock
    Vss = eye(size(Mss,1))-R'*pinv(R*R')*R; % var. of structural shock
    e_aux = Mss + (randn(1,size(Mss,1))*real(sqrtm(Vss)))';
    edraw = reshape(e_aux,nvar,fhor)';
    
    % conditional forecast using new draw of shock
    condfc = zeros(fhor+nlag,nvar);
    condfc(1:nlag,:) = Y(end-nlag+1:end,:);
    for k = nlag+1:fhor+nlag
        x = NaN(1,nlag*nvar);
        for i = 1:nlag
            x((i-1)*nlag+1:i*nlag) = condfc(k-i,:);
        end
        condfc(k,:) = [x 1]*bet + edraw(k-nlag,:)*A0;
    end
    condfc = condfc(nlag+1:end,:);
    
    
    %% save results
    if ii > nburn
        fdraw(ii-nburn,:,:) = condfc;
    end
    waitbar(ii/(ndraw+nburn));
end

close(wb)


%% plot forecast
figure('name','Conditional forecast of the variables')
for pp = 1:numel(pnam)
    fc = prctile(squeeze(fdraw(:,:,pp)),[5 16.7 50 83.3 95],1)';
    Yp = [repmat(Y(:,pp),1,size(fc,2)); fc];
    subplot(1,2,pp)
    plot(tim,Yp)
    xlim([2005 2012])
    title(pnam{pp})
    if pp==1; legend('5%','16.7%','50%',...
            '83.3%','95%','Location','SouthWest'); end
end
