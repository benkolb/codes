
function [ys,check] = TBDSGE_steadystate(ys,exo)
% function [ys,check] = NK_baseline_steadystate(ys,exo)
% computes the steady state for the NK_baseline.mod and uses a numerical
% solver to do so
% Inputs:
% - ys [vector] vector of initial values for the steady state of
% the endogenous variables
% - exo [vector] vector of values for the exogenous variables
%
% Output:
% - ys [vector] vector of steady state values fpr the the endogenous variables
% - check [scalar] set to 0 if steady state computation worked and to
% 1 of not (allows to impos restriction on parameters)

global M_

% read out parameters to access them with their name
NumberOfParameters = M_.param_nbr;
for ii = 1:NumberOfParameters
    paramname = deblank(M_.param_names(ii,:));
    eval([ paramname ' = M_.params(' int2str(ii) ');']);
end
% initialize indicator
check = 0;

%% Enter model equations here
options=optimset(); % set options for numerical solver

% Note: steady-state computations quite different from FVRR
PI=PIbar;
d=1;
phi=1;

%NEW: r
R=PI/bet;
r=R/PI-1+del;

%set Rbar
Rbar=R;

PIstar=((1-tetp*PI^(-(1-ela)*(1-chi)))/(1-tetp))^(1/(1-ela));
mc=(ela-1)/ela*(1-bet*tetp*PI^((1-chi)*ela))/(1-bet*tetp*PI^(-(1-ela)*(1-chi)))*PIstar;
w=(1-alf)*(mc*(alf/r)^alf)^(1/(1-alf));
vp=(1-tetp)/(1-tetp*PI^((1-chi)*ela))*PIstar^(-ela);
tempvaromega=alf/(1-alf)*w/r;


% fsolve uses the following steady-state equations:
% y=c+x=c+del*k; 
% y=(k^alf*l^(1-alf))/vp; 
% r=(R/PI-1)+del=(1/bet-1)+del; 
% k=tempvaromega*l;
% psy*l^gam=w/c;
[ld,fval,exitflag]=fsolve(@(ld)...
    (((tempvaromega*ld)^alf * ld^(1-alf))/vp...
    -del*tempvaromega*ld...
    - w/psy/ld^gam),...
    1/3,options);
l  = ld;
disp(l)

k=tempvaromega*l; 
x=del*k;
yd=(k^alf*ld^(1-alf))/vp;
c=(vp^(-1)*tempvaromega^alf-tempvaromega*del)*ld;
lam=1/c;
g1=lam*mc*yd/(1-bet*tetp*PI^((1-chi)*ela));
g2=ela/(ela-1)*g1;

%% end own model equations
for iter = 1:length(M_.params) %update parameters set in the file
    eval([ 'M_.params(' num2str(iter) ') = ' M_.param_names(iter,:) ';' ])
end

NumberOfEndogenousVariables = M_.orig_endo_nbr; %auxiliary variables are set automatically
for ii = 1:NumberOfEndogenousVariables
    varname = deblank(M_.endo_names(ii,:));
    eval(['ys(' int2str(ii) ') = ' varname ';']);
end