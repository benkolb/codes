
function [L, x] = kalmanf(y,F,G,M,R)

% Uses the Kalman filter to calculate the likelihood of a model in
% state-space form 
%
%      states(t) = F*states(t-1) + G*e(t),  e(t)~N(0,I)    
%         obs(t) = M*states(t)   + v(t),    v(t)~N(0,R)
%
% given observables y and C=M*F, D=M*G, where M is a "matching" matrix 
% connecting series in the observables with the corresponding states.
% Note:   - The function assumes zeros as starting values for states (fits
%           log-linearised models)
%         - returns "Inf" if MSE of forecasts is not positive semidefinite 
%         - so far, the code involves no measurement error
% 
% Usage:  L = kalmanf(y,F,G,M,R)
% 
% Input:  y:   vector of observables      
%         F,G: matrices of the model in state-space form
%         M:   matrix matching observables and model variables
%         R:   variance-covariance matrix of measurement error
% 
% Output: L:   log likelihood of the model
%         x:   estimates for the unobservable states x(t), (n
%
% By Benedikt Kolb (March 2015)

%% Housekeeping
[T,~] = size(y);              % dimensions of data matrix
ns    = size(F,1);            % # state variables (exog. st. vars & shocks)

%% Intial values for the system
x     = zeros(1,ns);          % mean of log-lin'd states
Sigma = (eye((ns^2))-kron(F,F)) \ reshape(G*G',(ns^2),1);
Sigma = reshape(Sigma,ns,ns); % uncond. var. of MSE of forecasts
% alternatively (comment out for initialising Sigma by Lyapunov equation):
% Sigma = lyapunov_symm(F,G*G',1); % requires Dynare's lyapunov.m
L     = -ns*T*log(2*pi)/2;    % initialise (log) likelihood


%% Kalman filter
for tt=1:T;   
   
   % Update forecast error and MSFE of observables
   innov = y(tt,:) - x(tt,:)*M';
   Omega = M*Sigma*M' + R;
   
   if det(Omega)<= 0;
       L     = -Inf;
       return;
   end
   
   % Accumulated model log likelihood (scaled, non-determ. part of it)
   L     = L - (log(det(Omega)) + innov/Omega*innov')/2;
   
   % Kalman gain
   K     = (F*Sigma*F' + G*G')*M'/Omega;
      
   % Prediction equations for states and their MSFE
   x(tt+1,:)     = x(tt,:)*F' + innov*K';
   Sigma = F*Sigma*F' + G*G' - K*Omega*K';
   
end

end

