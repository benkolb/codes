
function [LO,HI,ME] = VARConfInt(VAR,IRF_opt,ndraws,cnf_lvl)

% Calculates confidence bands for a VAR using bootstrapping.
%
% Usage:   [LO,HI,ME] = VARConfInt(VAR,IRF_opt,ndraws,cnf_lvl)
%
% Inputs:  VAR:     VAR results from VARreg
%          IRF_opt: Options of the IRFs (is the output of VAR)
% (opt.)   ndraws:  number of bootstrap draws (default: 100)
% (opt.)   cnf_lvl: Confidence level (default: 90)
%
% Outputs:
% Three arrays of dimension(h,v,s): horizon h, variable v, shock s
%          LO:     Lower confidence band
%          HI:     Upper confidence band
%          ME:     Median response
%
% by B. Kolb, Mar. 2015, based on code by A. Cesa Bianchi (VARirband.m)

% CAREFUL: I've changed the column order w.r.t. Ambrogio's codes!

%% Some renaming, checking and pre-allocating
hor      = IRF_opt.hor;
Ft       = VAR.Ft;  % rows are coefficients, columns are equations
nvars    = VAR.nvar;
nexog    = VAR.nexog;
nlags    = VAR.nlags;
determ   = VAR.determ;
nobs     = VAR.nobs;

if nexog~=0
    exog = VAR.X_EX;
end

% Defaults
if ~exist('ndraws','var')
    ndraws = 100;
end

if exist('cnf_lvl','var')
    pctl = cnf_lvl;
else
    pctl = 90;
end

LO = NaN(hor,nvars,nvars);
HI = NaN(hor,nvars,nvars);
ME = NaN(hor,nvars,nvars);
data_draws = NaN(nobs,nvars); % forecasts of VAR plus innov terms
IRF = NaN(hor,nvars,nvars,ndraws); % IRF across draws

%% Draw innovations, generate data, estimate VAR on them and get IRFs

wbar    = waitbar(0,'1','Name','Taking draws for confidence intervals');

for tt=1:ndraws
    
    waitbar(tt/ndraws,wbar,sprintf('%12.9f',tt/ndraws))
    
    % draw random innovations from resids (with replacement):
    innov = VAR.resid(ceil(nobs*rand(nobs,1)),:);
    
    % clear regressor vectors
    regr_lag = NaN(1,nvars*nlags); % lags for FC regressors
    if nexog~=0 % all FC regressors (incl. determ & exog.)
        regr_all = NaN(1,nvars*nlags+determ+nexog);
    else % all FC regressors (incl. determ)
        regr_all = NaN(1,nvars*nlags+determ);
    end
    
    for jj = 1:nobs
        % Intialise first draw with first data plus random innov
        if jj < nlags+1 
            data_draws(jj,:) = VAR.y(jj,:) + innov(jj,:);
            switch jj % create regressors recursively
                case 1 % first iteration
                    regr_lag(1:nvars) = data_draws(jj,:);
                otherwise % all others
                    regr_lag(1:jj*nvars) = ...
                        [data_draws(jj,:) ...
                        regr_lag(nvars*(jj-2)+1:(jj-1)*nvars)];
            end
        % in all other iterations, forecast from data and add innov    
        else 
            for mm = 1:nvars
                data_draws(jj,mm) = regr_all*Ft(1:end,mm) + innov(jj,mm);
            end
            % update regr_lag matrix
            regr_lag = [data_draws(jj,:) regr_lag(1,1:(nlags-1)*nvars)];
        end
        
        % Add determ. terms exog. vars to get all regressors for forecast
        switch determ
            case 0
                regr_all = regr_lag;
            case 1
                regr_all = [1 regr_lag];
            case 2
                T = (1:nobs)';
                regr_all = [1 T(jj) regr_lag];
            case 3
                T = (1:nobs)';
                regr_all = [1 T(jj) T(jj).^2 regr_lag];
        end
        if nexog~=0
            regr_all(1,nvars*nlags+determ+1:end) = exog(jj,:);
        end
    end
   
    % get one VAR draw estimated on created data (per iteration)
    if nexog~=0
        VAR_draw = VARreg(data_draws(1:end,:),nlags,determ,exog);
    else
        VAR_draw = VARreg(data_draws(1:end,:),nlags,determ);
    end
    
    % calculate and save impulse responses for draw
    [IRF(:,:,:,tt), ~] = ...
        VARImpResp(VAR_draw,hor,IRF_opt.ident,IRF_opt.impact);
    
end
close(wbar);


%% Compute percentiles (cnf_lvl upper and lower percentile + median)
pctl_inf = (100-pctl)/2;
pctl_sup = 100 - (100-pctl)/2;
LO(:,:,:) = prctile(IRF(:,:,:,:),pctl_inf,4);
HI(:,:,:) = prctile(IRF(:,:,:,:),pctl_sup,4);
ME(:,:,:) = prctile(IRF(:,:,:,:),50,4);

