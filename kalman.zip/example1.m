
% Example 1: Code to maximise likelihood of a New 
% Keynesian model with a financial accelerator over 
% one parameter to illustrate the use of the Kalman 
% filter. 
% This code is available under 
% http://www.bkolb.eu/codes/kalman_filter
% by Benedikt Kolb, Sept. 2015

clear all; clc;

%% Load data, write data vector and the model's var-cov matrix
dat = open('dat_full.mat'); % data come as [Y C I P R S]
y   = dat.dy;
[~,nd] = size(y);

% Theta gives the parameters; their meaning does not matter here.
Theta = [0.99,0.9728,0.025,0.75,2,1.5,0.125,0.5,0.3,0.9,0.5,0.5,0.5, ...
         0.5,0.5,0.0625,0.0625,0.0625,0.0625,0.0625,0.0625]';
Sigma = diag([Theta(16),...  % technology shock
              Theta(17),...  % monetary policy shock
              Theta(18),...  % gvt spending shock
              Theta(19),...  % preference shock
              Theta(20),...  % shock to financial accelerator
              Theta(21)]);   % xi
          
% Set size of measurement error as a scalar (the higher it is, the less 
% you trust the fit of your observables to model variables)
meas_err = 0.5;
R = eye(nd)*meas_err;

% H, matching observables from dy into measurement equation
ns = 16;     % # states in model
H       = zeros(nd,ns);
H(1,5)  = 1; % Y = y(t)
H(2,6)  = 1; % C = c(t)
H(3,7)  = 1; % I = i(t)
H(4,8)  = 1; % P = pi(t)
H(5,9)  = 1; % R = rn(t)
H(6,10) = 1; % S = cs(t)


%% Grid search for "optimal" elasticity phi (8th entry of Theta vector)
ngri = 100; % gridsize
grid = linspace(.25,0.75,ngri);
L    = NaN(10,1);

for phi = 1:ngri
    Theta(8) = grid(phi);
    [PP,QQ,~,~,NN,PROBLEM] = uhligsolve(Theta); % as in Uhlig (1999)
    if PROBLEM==1 %  if 1, there's a problem for Uhlig to find solution
        L=-Inf;
        return;
    end
    
    % prepare Kalman filter
    Fl      = [PP QQ*NN; zeros(size(NN,1),size(PP,2)) NN];
    Gl      = [QQ*Sigma; Sigma];
    
    ns = size(PP,1) + size(NN,1);
    
    % obtain model likelihood
    [L(phi) xx] = kalmanfilter(y,Fl,Gl,H,R);
    
    % If you prefer more dense or more extensive code:
    % [L(phi) xd]   = kalmanfilter_dense(y,Fl,Gl,H,R);
    % [L(phi) xe]   = kalmanfilter_extensive(y,Fl,Gl,H,R);
    
end

[val pos] = max(L(:));
pos = ind2sub(size(L),pos);

disp('Value of phi that maximises likelihood:')
disp(grid(pos))
disp('Maximised likelihood:')
disp(L(pos))
    