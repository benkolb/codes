
% this file generates graphs replicating some figures in Meeks, 
% Nelson and Alessandri (2014, BoE WP 487)
% it should be available on http://bkolb.eu/codes/MNA14.zip
% by Benedikt Kolb, May 2016

clear; close all; clc;
addpath(genpath('C:\_Research\QE\code'));
addpath(genpath('C:\_Research\codes\dynare'));

dynare RBC_MNASS_RiskTaking2
IRFsRT = oo_.irfs;
save('IRFsRT','IRFsRT')
dynare RBC_MNASS_noWB
IRFnWB = oo_.irfs;
save('IRFnWB','IRFnWB')
dynare RBC_MNASS_RiskSharing2
IRFsRS = oo_.irfs;

%% comparison e_cr with (kaps1,kapm1) = {(0,0),(0,5),(5,0)}
kapm_vec = [0,   0, 10];
kaps_vec = [0, 100,  0];
    
set_param_value('kaps1',kaps_vec(1));
set_param_value('kapa1',kapm_vec(1));
info = stoch_simul(var_list_);
IRF1 = oo_.irfs;
set_param_value('kaps1',kaps_vec(2));
set_param_value('kapa1',kapm_vec(2));
info = stoch_simul(var_list_);
IRF2 = oo_.irfs;
set_param_value('kaps1',kaps_vec(3));
set_param_value('kapa1',kapm_vec(3));
info = stoch_simul(var_list_);
IRF3 = oo_.irfs;

eta_vec  = [1, 0, 0.5];
set_param_value('kaps1',kaps_vec(1));
set_param_value('kapa1',kapm_vec(1));
set_param_value('eta',eta_vec(1));
info = stoch_simul(var_list_);
IRFeta1 = oo_.irfs;
set_param_value('eta',eta_vec(2));
info = stoch_simul(var_list_);
IRFeta0 = oo_.irfs;
set_param_value('eta',eta_vec(3));
info = stoch_simul(var_list_);
IRFeta5 = oo_.irfs;
% M_.params(strmatch('kaps1',M_.param_names))


%% plot IRF comparison: MNA FIGURE 4
load('IRFsRT');
load('IRFnWB');
snam = {'e_a','e_b','e_f'}; % 'e_a','e_g',
vnam = {'Y','I','Splot','Aplot','SPRSA'}; % ,'CBBS'
vtit = {'Output Y_t','Inv. I_t','Loans S_t^c','Assets A_t^w','Spread R_{k,t}-R_{a,t}'}; % ,'CeB balance sheet'
stit = {'Supply shock','Demand Shock','Financial Shock'};
hor  = length(IRF1.Y_e_a);
tim  = 1:hor;
figure('name','IRF_comparison MNA14 Figure 4')
for ss = 1:numel(snam)
    for vv = 1:numel(vnam)
        subplot(numel(vnam),numel(snam),(ss-1)+vv+2*(vv-1))
        eval(strcat('plot(tim,IRFsRS.',vnam{vv},'_',snam{ss},',''k'',''Linewidth'',2); hold on;')); axis tight;
        eval(strcat('plot(tim,IRFsRT.',vnam{vv},'_',snam{ss},',''r--'');; hold on;')); axis tight;
        eval(strcat('plot(tim,IRFnWB.',vnam{vv},'_',snam{ss},',''b-.'');; hold on;')); axis tight;
        plot(zeros(hor,1),'g')
        if vv == 1 && ss == 2; legend('\eta=1','\eta=0','1 bank',...
                'Location','SouthEast'); end % ,'no WB'
        if ss == 1;            ylabel(vtit{vv}); end
        if vv == 1;            title(stit{ss});  end
    end
end


%% plot IRF comparison: FINANCIAL CRISIS
snam = {'e_c'}; % 'e_a','e_g',
vnam = {'Y','I','Splot','Aplot','SPRA','Q'}; % ,'CBBS'
vtit = {'Output Y_t','Investm. I_t','Loans S_t^c','Assets A_t^w','Spread R_{a,t}-R_t','Cap. price Q_t'}; % ,'CeB balance sheet'
% vnam = {'SPREADK','SPREADM','Q','I','PIP','CBBS','PHIW','PHIC','RD'}; %  Y PIP R I Q SPREADK SC M SPREADM
% vtit = {'Loan spread R_{k,t+1}-R_t','Asset spread R_{a,t}-R_t','Price of capital Q_t','Investment I_t','Inflation \pi_t','CeB balance sheet','WB leverage','ComB leverage','Deposit rate'}; % Loans S_t^c
hor  = length(IRF1.Y_e_c);
tim  = 1:hor;
grey = [205 201 201]/255;
figure('name','IRF_comparison MNA14 Figure 5')
for ss = 1:numel(snam)
    for vv = 1:numel(vnam)
        subplot(3,3,vv)
        eval(strcat('plot(tim,IRF1.',vnam{vv},'_',snam{ss},',''k'',''Linewidth'',2); hold on;')); axis tight;
        eval(strcat('plot(tim,IRF2.',vnam{vv},'_',snam{ss},',''r--'');; hold on;')); axis tight;
        eval(strcat('plot(tim,IRF3.',vnam{vv},'_',snam{ss},',''b-.'');; hold on;')); axis tight;
        plot(zeros(hor,1),'g')
        plot(tim,zeros(length(hor)),'Color',[205 201 201]/255);
        if vv == 5; legend('\kappa_s=\kappa_a=0','\kappa_s>0',...
                '\kappa_a>0','Location','NorthEast'); end
        ylabel(vtit{vv})
    end
end

% saveas(gcf,strcat('..\..\figures\irfs_e_cr.pdf'));

