
clear; close all; clc;
% addpath(genpath('C:\dynare'));


%% 1) obtain steady state of IQ using fminsearch
% Parameters (copy from .mod file)
alf   = 0.85;   % Degree of price rigidity
bet   = 0.99;   % Household discount factor
del   = 2;      % Inverse elasticity of intertemporal substitution in consumption
tet   = 6;      % Steady-state value of intratemporal elasticity of substitution
psi   = 0.5;    % Inverse Frisch elasticity of labour supply
phi   = 1.1;    % Inverse of returns to scale in production
tau   = 20;     % Horizon of long-term bond
tp    = 0.5;    % Share of firm profits received by the government
f     = 0.66;   % Parameter in long-term bond supply rule
a1    = 0.95;   % Asset demand
a2    = 0;      % Asset demand
gB    = 10.21;  % Asset demand (subsistence level of B)
gQ    = 0.59;   % Asset demand (subsistence level of Q)
gamp  = 1.5;
gamy  = 0.5;
gqep  = 1.5;
gqey  = 0.5;
PISS  = 1.005;  % Steady-state inflation
GYSS  = 0.4;    % Steady-state ratio of government spending to GDP
rho_n = 0.1;    % Persistence of shock to interest rate rule
rho_x = 0.1;    % Persistence of shock to asset purchase rule
rho_c = 0.1;    % Persistence of consumption preference shock
rho_l = 0.7;    % Persistence of labour supply preference shock
rho_g = 0.1;    % Persistence of government spending
rho_a = 0.7;    % Persistence of technology shock
rho_t = 0.95;   % Persistence of shock to elasticity of substitution
sig_n = 0.0025; % Standard deviation of shock to interest rate rule
sig_x = 0.0025; % Standard deviation of shock to asset purchase rule
sig_c = 0.0025; % Standard deviation of consumption preference shock
sig_l = 0.0025; % Standard deviation of labour supply preference shock
sig_g = 0.005;  % Standard deviation of government spending shock
sig_a = 0.01;   % Standard deviation of technology shock
sig_t = 0.06;   % Standard deviation of shock to elasticity of substitution


% Steady States (copy from .mod file)
PI = log(PISS);
D  = log((1-alf)/(1-alf*PISS^(tet*phi))*((1-alf*PISS^(tet-1))...
         /(1-alf))^(tet*phi/(tet-1)));
Y  = log(((1-alf*bet*PISS^(tet-1))/(1-alf*bet*PISS^(tet*phi))...
         *(tet*phi)/(tet-1)*exp(D)^psi*(1-GYSS)^del...
         *((1-alf*PISS^(tet-1))/(1-alf))^((tet*(phi-1)+1)...
         /(tet-1)))^(1/(1-del-phi*(psi+1))));
G  = log(GYSS*exp(Y));
C  = log(exp(Y)-exp(G));
F  = log(exp(Y)*exp(C)^(-del)/(1-alf*bet*PISS^(tet-1)));
K  = log(1/(1-alf*bet*PISS^(tet*phi))*tet*phi/(tet-1)...
         *exp(D)^psi*exp(Y)^(phi*(psi+1)));
L  = log(exp(D)*exp(Y)^phi);
W  = log(exp(L)^psi*exp(C)^del);
PS = log(bet/PISS);
QB = log(f*exp(Y));
Q  = QB;
S  = log(PISS/(1-bet)*(exp(C)+exp(G)-tp*exp(W)*exp(L)-(1-tp)*exp(Y)));
B  = log(exp(S)-exp(Q)/tau*(1-1/PISS^tau)*PISS/(PISS-1));
PB = log(a1*exp(PS)*exp(S)/(exp(B)-(1-a1)*gB...
                            +(1-a1)*(exp(B)-gB)/(exp(Q)-gQ)*gQ));
PQ = log((1-a1)/a1*(exp(B)-gB)/(exp(Q)-gQ)*exp(PB));

% get PQ in levels
PQ = exp(PQ);

% run fminsearch
startval = (1/0.99-1)/tau;
ubound = 1;
lbound = 0;
options = optimset('Algorithm','interior-point',...
    'MaxFunEvals',10000,'MaxIter',200,'TolFun',1e-30);
[iQ_min,FVAL,EXITFLAG,OUTPUT] = fminsearch(...
    @(iQ) (PQ - (1-(1/(1+iQ))^tau)/(1-1/(1+iQ))/tau/(1+iQ))^2,...
    startval,options);

% check result
disp(strcat('iQ_min:',sprintf('%.16f ', iQ_min)))
disp(strcat('f:',num2str((PQ - (1-(1/(1+iQ_min))^tau)/(1-1/(1+iQ_min))/tau/(1+iQ_min)  ))))

% [copy the steady state for IQ back into .mod file manually]


%% 2) simulate .mod file
dynare ET_redo
IRF = oo_.irfs;


%% 3) plot graphs like Figure 1 and 2
snam = {'e_n','e_x'}; 
stit = {' the nominal interest rate',' long-term bond purchases'};
vnam = {'PI','Y','I','PB','PQ','PSS','B','Q','S','QCB','L','W'};
vtit = {'\Pi','Y','i','P^B','P^Q','P^Ss','b','q','s','q^CB','L','w'};
hor  = length(IRF.Y_e_n);
tim  = 1:hor;
for ss = 1:numel(snam)
    eval(strcat('figure(''name'',''Responses to ',stit{ss},''')'))
    for vv = 1:numel(vnam)
        subplot(4,3,vv)
        eval(strcat('plot(tim,IRF.',vnam{vv},'_',snam{ss},',''k'',''Linewidth'',1); hold on;')); axis tight;
        plot(zeros(hor,1),'r')
        title(vtit{vv})
    end
    eval(strcat('saveas(gcf,strcat(''ETredo_',snam{ss},'.pdf''))'));
end


