
function draw = iwpQ_bk(v,ixpx)
% takes a draw from Inverse Wishart distribution with degrees of freedom v
% and scale parameter S:
% draw = iwpQ(v,S)

k = size(ixpx,1);
z = zeros(v,k);
for i=1:v
    z(i,:)=(chol(ixpx)'*randn(k,1))';
end
draw = eye(k)/(z'*z);

