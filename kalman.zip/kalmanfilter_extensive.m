
function [L x] = kalmanfilter_extensive(y,F,G,H,R)

% Uses the Kalman filter to calculate the likelihood of a model in
% state-space form 
%
%      states(t) = F*states(t-1) + G*e(t),  e(t)~N(0,I)    
%         obs(t) = H*states(t)   + v(t),    v(t)~N(0,R)
%
% given observables y and where H is a "matching" matrix connecting series 
% in the observables with the corresponding states.
% Note:   - The function assumes zeros as starting values for states (fits
%           log-linearised models)
%         - returns "Inf" if MSE of forecasts is not positive semidefinite 
% 
% Usage:  [L x] = kalmanfilter_extensive(y,F,G,H,R)
% 
% Input:  y:   vector of observables      
%         F,G: matrices of the model in state-space form
%         H:   matrix matching observables and model variables
%         R:   variance-covariance matrix of measurement error
% 
% Output: L:   log likelihood of the model
%         x:   estimates for the unobservable states x(t), (1 x ns)
%
% By Benedikt Kolb (Sept. 2015)


%% Housekeeping
if size(y,1) > size(y,2)
    y = y';
end
[ny,T] = size(y);              % dimensions of data matrix
ns     = size(F,1);            % # state variables (exog. st. vars & shocks)


%% Intial values for the system
x     = zeros(ns,T);          % mean of log-lin'd states

% uncond. var. of MSE of forecasts
Sigma = reshape( (eye((ns^2))-kron(F,F)) \ reshape(G*G',(ns^2),1) ,ns,ns); 

% alternatively (comment out for initialising Sigma by Lyapunov equation):
% Sigma = lyapunov_symm(F,G*G',1); % requires Dynare's lyapunov.m

L     = -T*ny*log(2*pi)/2;    % initialise (log) likelihood

% only for extensive KF: initialise x00 and Sigma00
x00     = x(:,1);
Sigma00 = Sigma;


%% Kalman filter algorithm
for tt=1:T;
   
   % Prediction equation I: x(t) given info in t-1, i.e. x(t|t-1)
   x10     = F*x00;
   
   % Forecast error
   innov   = y(:,tt) - H*x10;
   
   % Prediction equation II: Sigma(t) given info in t-1, i.e. Sigma(t|t-1)
   Sigma10 = F*Sigma00*F' + G*G';
   
   % Predict Omega(t) given info in t-1, i.e. Omega(t|t-1)
   Omega   = H*Sigma10*H' + R;
   
   % Accumulated model log likelihood (scaled, non-determ. part of it)
   if det(Omega) <= 0;
       L   = -Inf;
       return;
   else
       L   = L - (log(det(Omega)) + innov'/Omega*innov)/2;
   end
   
   % Kalman gain
   K       = Sigma10*H'/Omega;
   
   % Updating equation I: x(t) given info in t, i.e. x(t|t)
   x11     = x10 + K*innov;
   
   % Save the estimated states 
   x(:,tt) = x11;
   
   % Updating equation II: Sigma(t) given info in t, i.e. Sigma(t|t)
   Sigma11 = (eye(ns) - K*H)*Sigma10;
   
   % Initialisation of next iteration I: x(t|t) becomes x(t-1|t-1)
   x00     = x11;
   
   % Initialisation of next iteration II: Sigma(t|t) becomes Sigma(t-1|t-1)
   Sigma00 = Sigma11;
   
end

end

