
function [ys,check] = simple_rbc_steadystate(ys,exo)

% Computes the steady state of the simple RBC model.
% function [ys,check] = diff_crws_steadystate(ys,exo)
% Inputs:
%   - ys        [vector] vector of initial values for the steady state of
%                   the endogenous variables
%   - exo       [vector] vector of values for the exogenous variables
% Output:
%   - ys        [vector] vector of steady state values for the endogenous variables
%   - check     [scalar] set to 0 if steady state computation worked and to
%                    1 of not (allows to impose restriction on parameters)
% Benedikt Kolb, Oct 2014
% based codes from Dynare forum

global M_ lgy_

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DO NOT CHANGE THIS PART.
% read out parameters to access them with their name
if isfield(M_,'param_nbr')==1
    NumberOfParameters = M_.param_nbr;                            % Number of deep parameters.
    for i = 1:NumberOfParameters                                  % Loop...
        paramname = deblank(M_.param_names(i,:));                   %    Get the name of parameter i.
        eval([ paramname ' = M_.params(' int2str(i) ');']);         %    Get the value of parameter i.
    end
    % initialize indicator
    check = 0;
end
%% END OF THE FIRST MODEL INDEPENDENT BLOCK.



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% THIS BLOCK IS MODEL SPECIFIC.
%% set options for numerical solver
options=optimset('Display','off','Algorithm',{'levenberg-marquardt',.01});
% for default solving algo, replace: 'Algorithm','trust-region-dogleg'

%% Here the user has to define the steady state
x0=1;
params_names={'alf','bet','del','rho','sig'};
for ii = 1:length(params_names);
    eval(strcat('params.',params_names{ii},' = ',params_names{ii},';'))
end
[solved_for,~,exitflag]  =   fsolve(@diff_moment,x0,options,params); 
if exitflag <1
    %indicate the st.st. computation was not sucessful; this would also be detected by Dynare
    check=1; %set failure indicator
    return;  %return without updating steady states
end

k = solved_for(1);
a = 1;
y = k^alf;
c = k^(alf)-del*k;

%% END OF THE MODEL SPECIFIC BLOCK.



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DO NOT CHANGE THIS PART.
%% Update parameters set in the file
% These should be chi, deltas_ss, b, delta_c
for iter = 1:length(M_.params)
    eval([ 'M_.params(' num2str(iter) ') = ' M_.param_names(iter,:) ';' ])
end
if isfield(M_,'param_nbr') == 1
    if isfield(M_,'orig_endo_nbr') == 1
        NumberOfEndogenousVariables = M_.orig_endo_nbr;
    else
        NumberOfEndogenousVariables = M_.endo_nbr;
    end
    %% Here we define the steady state values of the endogenous variables of the model.
    ys = zeros(NumberOfEndogenousVariables,1); % Initialization of ys (steady state).
    for ii = 1:NumberOfEndogenousVariables %-size(M_.aux_vars,2)
        varname = deblank(M_.endo_names(ii,:));
        eval(['ys(' int2str(ii) ') = ' varname ';']);
    end
else
    ys=zeros(length(lgy_),1);
    for ii = 1:length(lgy_)
        ys(ii) = eval(lgy_(ii,:));
    end
    check = 0;
end
%% END OF THE SECOND MODEL INDEPENDENT BLOCK.

end
