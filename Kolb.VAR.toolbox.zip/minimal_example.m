
clear all; clc;
Y = csvread('example_data.csv',1,1);
determ = 2; % deterministic regressors: constant + (linear) time trend
[~,~,qBIC,~,~] = lagselect(Y,12,determ,0); % max. lags: 12, no result table
VARresults = runVAR(Y,qBIC,determ);
disp('Beta matrix:  ') 
disp(VARresults.Ft)
