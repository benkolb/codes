
% Code to redo example 6.1 from chapter 2 in Blake/Mumtaz (BoE, 2014)
% Using dummy observation priors and (efficient) sign restrictions
% by Benedikt Kolb, June 2016


%% Housekeeping
clear; close all;
rng(42);


%% set Gibbs sampler options and pre-allocate
ndraw = 2000; % # draws (after burn-in); default: 2000
nburn = 3000; % # burn-in draws; default: 3000
nrot  = 100;   % # rotations of A0 draw
ndet  = 1;     % # deterministic regressors
nlag  = 2;     % # lags
hor   = 36;    % horizon for structural IRFs
fhor  = 12;    % forecast horizon
% data-specific setting
pnam  = {'Federal Funds Rate','GDP Growth','CPI inflation',...
    'PCE Growth','Unemployment','Investment','Net Exports',...
    'Money (M2)','10-yr Gvt. Bond Yield','Stock Price Growth',...
    'Yen-Dollar Exch. Rate'};
tim   = 1948.75:0.25:2014;
% IRF-specific settings
spos  = 1; % position of variable to be shocked (in [1, nvar])
shimp = 1; % shock impact (set to 1, -1, sigma, etc.)


%% Load data and create Y and X
dat       = xlsread('data\usdata1.xls');
Y         = dat(nlag+1:end,:);
[T, nvar] = size(Y);
X         = NaN(T,nvar*nlag+ndet);
X(:,end)  = ones(T,1);
for ll=1:nlag
    X(:,(ll-1)*nvar+1:ll*nvar) = dat(nlag+1-ll:end-ll,:);
end
nbet      = nlag*nvar + ndet; % # beta coeffs (fewer b/o dummies!)


%% Priors
% CHECK BELOW!
% for Independent Normal Wishart prior, use Minnesota prior with L2=1
% lambdas for Minnesota prior in Blake/Mumtaz (see p33 of their script):

% prior for H (uses data twice; discouraged: better presample!)
s = NaN(nvar,1);
for kk = 1:nvar
    yy = Y(:,kk); xx = X(:,[1 kk+1]);
    bb = (xx'*xx)\(xx'*yy); % use AR(1)
    s(kk) = sqrt((yy-xx*bb)'*(yy-xx*bb)/(size(yy,1)-2))';
end

% Dummy observation prior parameters (Blake/Mumtaz p. 49)
tau   = 10;  % controls prior on own first lags
d     = 1;   % decay for higher lags
c     = 1;   % prior for the constant
lam   = 1;   % sum of coefficients unit roots
mu    = mean(Y)';    % data mean
% prior mean and variance of VAR coefficients: AR(1) coefficients
delta = NaN(nvar,1); % prior mean of VAR coefficients (AR1 coeff!)
sigma = NaN(nvar,1); % prior var  of VAR coefficients (AR1 coeff!)
for v = 1:nvar
    ytemp = Y(2:end,v);
    xtemp = [ones(T-1,1) Y(1:end-1,v) ];
    btemp = xtemp\ytemp;  % const + AR(1) coefficient
    etemp = ytemp-xtemp*btemp;
    stemp = etemp'*etemp/(T-1);
    delta(v) = btemp(2);
    sigma(v) = stemp;
end


%% Get dummy observations as in Banb�ra et al. (2007)
% see https://www.ecb.europa.eu/pub/pdf/scpwps/ecbwp966.pdf

% as in Banb�ra et al. (2007, p. 12), eq. (5)
if lam > 0
    if c > 0
        YD1 = [diag(sigma.*delta)./lam;
            zeros(nvar*(nlag-1),nvar);
            diag(sigma);
            zeros(1,nvar)];
        XD1 = [kron(diag(1:nlag),diag(sigma)./lam) zeros((nvar*nlag),1);
            zeros(nvar,(nvar*nlag)+1);
            zeros(1,nvar*nlag) c];
    else
        YD1 = [diag(sigma.*delta)./lam;
            zeros(nvar*(nlag-1),nvar);
            diag(sigma)];
        XD1 = [kron(diag(1:nlag),diag(sigma)./lam);
            zeros(nvar,(nvar*nlag))];
    end
else
    YD1 = [];
    XD1 = [];
end

% as in Banb�ra et al. (2007, p. 20), eq. (9)
if tau > 0
    YD2 = diag(delta.*mu)./tau;
    if c > 0
        XD2 = [kron((1:nlag),YD2) zeros(nvar,1)];
    else
        XD2 = kron((1:nlag),YD2);
    end
else
    YD2 = [];
    XD2 = [];
end

% Y and X augmented by dummy observations ("Ystar" and "Xstar")
Ys = [Y; YD1; YD2]; % Y0 in BM
Xs = [X; XD1; XD2]; % X0 in BM
Ts = size(Ys,1);


%% Starting values
mstar = vec(Xs\Ys);
Sig   = eye(nvar);

% bOLS      = (Xs'*Xs)\(Xs'*Ys);
% res       = Ys - Xs*bOLS;
% Sig       = (res'*res)/Ts;


%% Preallocate arrays to save draws of interest
bdraw = NaN(ndraw, nbet);
fdraw = NaN(ndraw, fhor, nvar); % forecast
irfs  = NaN(ndraw, hor-nlag, nvar); % response to (structural) shock


% ii=1;
% break


%% Gibbs sampler
wb = waitbar(0,'Gibbs sampling...');

for ii = 1:nburn+ndraw
    
    % draw bet
    vstar = kron(Sig,(Xs'*Xs)\eye(nbet));
    bet   = mstar + (randn(1,nvar*(nvar*nlag+1))*chol(vstar))';
    
    % draw Sig
    res  = Ys - Xs*reshape(bet,nvar*nlag+1,nvar);
    scl  = res'*res;
    aux = NaN(Ts,length(scl));
    for iw = 1:Ts
        aux(iw,:) = (chol(eye(nvar)/scl)'*randn(length(scl),1))';
    end
    Sig = eye(nvar)/(aux'*aux);
    
    if ii > nburn
        Adraw = NaN(nrot,nvar*nvar);
        counter = 1;
        for m = 1:nrot
            %impose sign restrictions
            chck = -1;
            
            while chck < 0 % unless 7 responses have correct sign
                K = randn(nvar,nvar);
                counter = counter + 1;
                
                % Get the QR decomposition of K
                [Q,R] = qr(K);
                % If diagonal elements of R are negative, multiply
                % corresponding column of Q by -1:
                for diagR = 1:size(Q,1)
                    if R(diagR,diagR) < 0
                        Q(:,diagR) = -Q(:,diagR);
                    end
                end
                
                A0c = Q*chol(Sig);  % A0 candidate draw
                
                for vv = 1:nvar
                    % check signs in each row
                    % Response of  R,  Y, Pi,  C,  U,  I,  M
                    %             >0, <0, <0, <0, >0, <0, <0 ?
                    test = (A0c(vv,1)>0)+(A0c(vv,2)<0)+(A0c(vv,3)<0)+ ...
                           (A0c(vv,4)<0)+(A0c(vv,5)>0)+(A0c(vv,6)<0)+ ...
                           (A0c(vv,8)<0);
                    if test == 7 % if all yes, save
                        MP   = A0c(vv,:);
                        chck = 10; % using chck=test slows down algorithm!
                    elseif test == 0 % if all no, save negative A0
                        MP   = -A0c(vv,:);
                        chck = 10;
                    end
                end
                %{
                for vv=1:nvar
                    %check signs in each row
                    e1=A0c(vv,1)>0;  %Response of R
                    e2=A0c(vv,2)<0;  %Response of Y
                    e3=A0c(vv,3)<0;  %Response of Inflation
                    e4=A0c(vv,4)<0;  %Response of consumption
                    e5=A0c(vv,5)>0;  %Response of U
                    e6=A0c(vv,6)<0;  %Response of investment
                    e7=A0c(vv,8)<0; %response of money
                    if e1+e2+e3+e4+e5+e6+e7==7
                        MP=A0c(vv,:);
                        chck=10;
                    else
                        %check signs but reverse them
                        e1=-A0c(vv,1)>0;  %Response of R
                        e2=-A0c(vv,2)<0;  %Response of Y
                        e3=-A0c(vv,3)<0;  %Response of Inflation
                        e4=-A0c(vv,4)<0;  %Response of consumption
                        e5=-A0c(vv,5)>0;  %Response of U
                        e6=-A0c(vv,6)<0;  %Response of investment
                        e7=-A0c(vv,8)<0; %response of money
                        if e1+e2+e3+e4+e5+e6+e7==7
                            MP=-A0c(vv,:);
                            chck=10;
                        end
                    end
                end
                %}
            end
            
            % re-order rows of A0c s.t. MP is first row
            idx1 = A0c-repmat(MP,nvar,1)~=0; % test == 7 case
            idx2 = A0c+repmat(MP,nvar,1)~=0; % test == 0 case
            if any(~any(idx1~=0,2)) %
                A0new = [MP; reshape(A0c(idx1),nvar-1,nvar)];
            elseif any(any(idx2,2))
                A0new = [MP; reshape(A0c(idx2),nvar-1,nvar)];
            end
            
            % save the mth rotation of A0 fulfilling sign restrictions
            Adraw(m,:) = reshape(A0new,nvar*nvar,1);
        end
                
        % find the A0 matrix closest to the median of the m draws
        med     = median(Adraw);
        dif     = sum((Adraw-repmat(med,nrot,1)).^2,2); % dist. to median
        [~, id] = min(dif);
        % finally, our candidate A0:
        A0      = reshape(Adraw(id,:),nvar,nvar);
        
        % compute and save IRFs
        yhat = zeros(hor,nvar);
        ep = zeros(hor,nvar); ep(nlag+1,spos) = shimp; % shock impulse
        for hh = 3:hor
            reg        = [yhat(hh-1,:) yhat(hh-2,:) 0];
            yhat(hh,:) = reg*reshape(bet,nvar*nlag+ndet,nvar)  ...
                + ep(hh,:)*A0;
        end
        irfs(ii-nburn,:,:) = yhat(nlag+1:end,:);
       
    end
    
    waitbar(ii/(ndraw+nburn));
end

close(wb)


%% Plot IRFs
TT = 1:hor-nlag;
pc = prctile(irfs,[50, 16, 84],1);
figure('name','Impulse responses to structural shock')
for pp = 1:numel(pnam)
    subplot(4,3,pp)
    plot(TT,pc(1,:,pp),'b',TT,pc(2,:,pp),'b--',TT,pc(3,:,pp),'b--');
    hold on;
    plot(TT,zeros(hor-nlag,1),'r')
    title(pnam{pp})
    axis tight
    if pp==2; legend('50%','16/84%','Location','SouthEast'); end
end



