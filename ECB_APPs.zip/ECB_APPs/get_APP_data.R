
## get harmonised data on ECB asset-purchasing programmes
## Benedikt Kolb with Rasmus Pank Roulund, July 2016



#################################################################
## Apply settings and load packages
Sys.setlocale("LC_ALL", "English")
library(xts)
do_plot = T # do you want to plot a graph of the series?


#################################################################
### Overall APP data (from SDW, item ILM.W.U2.C.A071.U2.EUR)
## load overall size of APP (saved as csv) and store as xts
appraw <- read.csv("ECB_daily_liq_data/APP.csv", sep=';')
# add day 
appraw$date2 <- paste0(appraw$date,"w2") # reported on Tuesdays (day "2")
# save as xts
app <- as.xts(appraw$app, as.Date(appraw$date2, format='%YW%Ww%w'))
# delete two entries too many, end-09 and end-15 (seem to aggregates outside weekly scheme)
app <- app[-which(is.na(index(app))),]
# make monthly and set name
appm <- setNames(apply.monthly(app, mean), "app")
# get end of month as index (instead of day of last observation)
index(appm) <- as.Date(as.yearmon(index(appm))+1/12)-1 # hack: add one month, then go back to last day of previous



#################################################################
### Daily liquidity data (several year-long files)
### (from https://www.ecb.europa.eu/stats/monetary/res/html/index.en.html)
## load daily liquidity data from saved csv files
L = lapply(list.files(path = "./ECB_daily_liq_data", full.names = T, pattern = "liq_daily"), read.csv)
# select anything with some APP-related keywords
L = lapply(L, function(x){
  c0 = colnames(x)
  data.frame(date=x[,1],      
    x[, grepl("(programme|^smp)", c0, ignore.case = T) # keep these
          & !grepl("(net.liquidity|Open.Market)", c0, ignore.case = T), drop=F])}) # get rid of these

# harmonise capitalisation of names (all lower-case)
L = lapply(L, function(x) setNames(x, tolower(colnames(x))))

# harmonise names for...
L = lapply(L, function(x){
  for (z in list(c("asset.backed.securities","abs"), # ... ABSPP
               c("(smp|securities.markets?.programme)","securities.markets.programme"))) # ... SMP
    colnames(x) = gsub(z[1], z[2], colnames(x))
  x})

# unique column names (ie names of APPs)
all_cols = unique(do.call(c,sapply(L,colnames)))

# make sure all APPs are listed & filled with NAs (also before they were introduced)
L = lapply(L, function(x){
  for (col in all_cols)
  if (!col %in% colnames(x))
    x[,col] = NA
  x})


## convert to data.frame and tweak dates
df <- do.call(rbind, L)
# replace initial zeros with NAs
for (i in seq(2,ncol(df)))
  df[df[,i] == 0 & !is.na(df[,i]), i] = NA 
# delete rows with no APPs at all
df2 = df[!apply(df[,-1],1,function(row) all(is.na(row))),] 
# harmonise years in date to "20xx" notation and save as date
df2[,'date']= as.character(df2[,'date'])
df2[,'date'] = with(df2, ifelse(nchar(date) == 10, date, paste0(substr(date,1,6),'20',substring(date,7))))
df2$date = as.Date(df2$date, format='%d/%m/%Y')


## convert to xts, make into monthly frequency and set shorter names
dat <- xts(df2[,-1], df2[,1])
dat <- apply.monthly(dat, mean)
dat <- setNames(dat, c('cbpp1','cbpp2','smp','cbpp3','abspp','pspp','cspp'))
# get end of month as index (instead of day of last observation)
index(dat) <- as.Date(as.yearmon(index(dat))+1/12)-1 # hack: add one month, then go back to last day of previous



#################################################################
### Combine SDW and daily APP data and save
## combine data files
out <- merge(dat,appm)
out[is.na(out)] <- 0
# create SMP as APP-CBPP1-CBPP2 before November 2014
repl_hor <- "2010-05-31/2014-10-31"
out$smp[repl_hor] <- out$app[repl_hor] - out$cbpp1[repl_hor] - out$cbpp2[repl_hor]
out$app <- NULL
# order acc. to time introduced
out <- out[, c('cbpp1','smp','cbpp2','abspp','cbpp3','pspp','cspp','')]
# save as csv
write.zoo(out, file="APP_data_monthly.csv", sep=",")


#################################################################
### Plot area chart of APPs
if (do_plot) {
# load required packages
library(ggplot2)
library(reshape2)
library(ggthemes)
# create dataframe again - and change from million to billion euro
pldf <- data.frame(time = index(out), melt(as.data.frame(out/1000)))
# plot
p <- ggplot(pldf, aes(x=time, y=value)) +
  geom_area(aes(colour = variable, fill= variable), position = 'stack')
p + theme_economist() + scale_colour_economist() 
}
