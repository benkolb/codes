
This collection of codes for Matlab/Octave is supposed to help using (S)VAR analysis and writing your own codes. So far, it can be used to bring a matrix of data in VAR form, run OLS equation by equation and determine the optimal lag length from several criteria.

Some of the codes are based on code by James P. LeSage, Fabio Canova and Ambrogio Cesa-Bianchi (see Cesa-Bianchi's "VAR Toolbox" on https://sites.google.com/site/ambropo/).

Copyright: What James P. LeSage states on his spatial econometrics site applies tho these codes: "Anyone is free to use these routines, no attribution (or blame) need be placed on the author/authors."

If you'd like to cite the toolbox in a paper, feel free to do so as:
Benedikt Kolb, "Kolb SVAR toolbox", available under www.bkolb.eu/codes

For bugs or comments, please contact me under benedikt@bkolb.eu.

-----------------------
For an overview of what the routines can do, run 
example_use_of_toolbox.m
For a (minimal) example of an SVAR that runs without my functions (but uses bits and pieces of them), run 
example_minimal_svar.m

The individual routines of the package are the following:
VARform:   Builds vectors of dependent variables and (independent) lags for a VAR.
VARreg:    Estimates a vector autogressive (VAR) system by OLS.
OLSreg:	  Regresses input y on input x using OLS.
lagselect: Calculates lag selection criteria for VARs - e.g. Bayesian IC, Ljung-Box Q test, likelihood ratio test.
tdis_inv:  Returns the inverse (quantile) at x of the t(n) distribution (by A. Holtsberg).
beta_inv:  Returns the inverse of the cdf (quantile) of the beta(a,b) distribution (by A. Holtsberg).
beta_pdf:  Returns the pdf of the beta(a,b) distribution (by A. Holtsberg).


What the toolbox cannot yet handle:
 - non-triangular matrices for short-run or long-run zero restrictions
 - Bayesian estimation
 


