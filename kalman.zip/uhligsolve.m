
function [PP,QQ,RR,SS,NN,PROBLEM] = uhligsolve(Theta)
% Puts a log-linearised model with parameters Theta into its state-space form.
% State-space form is:
%   x(t) = PP * x(t-1) + QQ * z(t)
%   y(t) = RR * x(t-1) + SS * z(t)
%   z(t) = NN * z(t-1) + epsilon(t), epsilon(t)~N(0,I)


%% "Translate" parameter names to be estimated
rhoa = Theta(end-11); % AR(1) param of tech   shock a(t)
rhov = Theta(end-10); % AR(1) param of monpol shock v(t)
rhog = Theta(end-9);  % AR(1) param of gvt sp shock g(t)
rhoc = Theta(end-8);  % AR(1) param of cost p shock cp(t)
rhoe = Theta(end-7);  % AR(1) param of pref   shock et(t)
rhox = Theta(end-6);  % AR(1) param of fin    shock xi(t)
% Last elements of Theta vector: std. deviations which are only needed in likehd_full.m!


%% Parametrise the model
alf     =   0.3257;			% Capital share of production
bet     =   Theta(1);		% Discount factor
gam     =   Theta(2);		% Survival rate of entrepreneurs
del     =   Theta(3);		% Depreciation rate
tet     =   Theta(4);		% Calvo parameter			
nu      =   0.1;            % Inverse elasticity of leverage to external funds premium
sig		= 	Theta(5);		% Risk aversion or inverse elasticity of intertemp. substitution
phipi   =   Theta(6);		% Weight of mon.pol. rule on inflation
phiy	=	Theta(7);		% Weight of mon.pol. rule on output deviations 
psi     =   Theta(8);		% Elasticity of price of capital Q w.r.t. investment-to-capital ratio I/K
Omg     =   0.99;			% Share of entrepreneurs' labour in total labour supply
CoY	    =	0.65;			% Cons. over GDP in st.st.
CeoY	=	0.01;			% Entrepreneurs' cons. over GDP in st.st. 
GoY     =   0.2;
IoY 	=	0.14;	 		% Investment over GPD in st.st. 
KoN 	=	1.5;			% Capital over net worth or inverse leverage in st.st.
KoY		=	3;   			% Capital (or assets) over GDP (where GDP is (IoY+CoY+CeoY)^-1)
YoN 	=	KoN/KoY;		% GDP over net worth in st.st.
R       =   1/bet;			% Riskless interest rate
X   	=	6/5; 			% Inverse relative price of the wholesale good or gross retailer markup
H		=	0.4;			% Hours worked in steady state
% composite parameter
epn     =   (1-del)/((1-del) + ((alf/X)*(YoN/KoN)));    % Composite parameter
kap     =   ((1-tet)/tet)*(1-tet*bet);    				% Weight on output gap in New Keynesian Phillips curve
Lam		=   (sig-1)/sig*H*alf/CoY;						% Elasticity of consumption w.r.t. labour supply


%% The equations are, conveniently ordered:
% non-expectational
% 1) 0 = -y(t) + CoY*c(t) + IoY*i(t) + CeoY*ce(t) + 0.2*g(t);			  // M.1  (comp. 4.14*)
% 2) 0 = -ce(t) + n(t);     	                                          // M.3  (comp. 4.16)
% 3) 0 = -rk(t) + (1-epn)*(y(t) - k(t-1) - x(t)) + epn*q(t) - q(t-1);     // M.5  (comp. 4.18)
% 4) 0 = -q(t) + psi*(i(t) - k(t-1));                                     // M.6  (comp. 4.19)
% 5) 0 = -y(t) + a(t) + alf*k(t-1) + (1-alf)*Omg*h(t);                    // M.7  (comp. 4.20*)
% 6) 0 = -c(t) + et(t) + sig*(1-sig)*(Lam/H)^2*h(t) + y(t) - h(t) - x(t); // M.8  (comp. 4.21*)
% 7) 0 = -k(t) + del*i(t) + (1-del)*k(t-1);							      // M.10 (comp. 4.23)
% 8) 0 = -n(t) + gam*R*KoN*(rk(t) - r(t-1)) + r(t-1) + n(t-1);            // M.11 (comp. 4.24)
% 9) 0 = -rn(t) + phipi*pi(t) + phiy*y(t) - v(t); 		        		  // M.12 (comp. 4.25)
% declare pseudo-states
% 10) 0 = p_y(t)  - y(t)
% 11) 0 = p_c(t)  - c(t)
% 12) 0 = p_i(t)  - i(t)
% 13) 0 = p_pi(t) - pi(t)
% 14) 0 = p_rn(t) - rn(t)
% 15) 0 = cs(t) - (rk(t) - r(t))
% expectational
% 0 = E_t { -c(t) + c(+1) - et(+1) - 1/sig * r(t) + Lam*(h - h(+1)) + et(t) };  // M.2  (comp. 4.15*)
% 0 = E_t { -rk(+1) + r(t) + nu*( q(t) + k(t) - n(t) ) + xi(t);           // M.4  (comp. 4.17*)
% 0 = E_t { -pi(t) + bet*pi(t+1) - kap*x(t) - cp(t)};                     // M.9  (comp. 4.22)
% 0 = E_t { -rn(t) + r(t) + pi(+1) };                                     // M.13 (new: Fischer eq.)
% shock processes
% a(t+1)  = rho_a*a(t)   + e_a(t+1);
% v(t+1)  = rho_v*v(t)   + e_v(t+1);
% g(t+1)  = rho_g*g(t)   + e_g(t+1);
% cp(t+1) = rho_cp*cp(t) + e_cp(t+1);
% et(t+1) = rho_et*et(t) + e_et(t+1);
% xi(t+1) = rho_xi*xi(t) + e_fn(t);                                       // M.14 (new: financial cost)

% Find matrices of format
% a) 0 = AA x(t) + BB x(t-1) + CC y(t) + DD z(t)
% b) 0 = E_t [ FF x(t+1) + GG x(t) + HH x(t-1) + JJ y(t+1) + KK y(t) + LL z(t+1) + MM z(t)]
% c) z(t+1) = NN z(t) + epsilon(t+1) with E_t [ epsilon(t+1) ] = 0
% =>
% Endogenous state variables "x(t)": k(t), n(t), q(t), r(t), 
% p_y(t), p_c(t), p_i(t), p_pi(t), p_rn(t), p_cs(t)
% Endogenous other variables "y(t)": c(t), h(t), i(t), pi(t), ce(t), rn(t), rk(t), x(t), y(t) 
% Exogenous state variables  "z(t)": a(t), v(t), g(t), cp(t), et(t), xi(t)
%
% Solution takes the form:   ESV(t) = P * ESV(t-1) + Q * XSV(t)
%                             CV(t) = R * ESV(t-1) + S * XSV(t)
%
% State-space form is:         x(t) = A * x(t-1)   + B * espilon(t)
%                              y(t) = C * x(t-1)   + D * epsilon(t)
% where x(t)=[ESV(t), XSV(t)],  A=[P  Q*N;  0  N] and B=[Q I]'*Sigma^.5




%% Create the Uhlig matrices
AA = [    0,   0,   0,   0,      0,   0,   0,   0,   0,   0
          0,   1,   0,   0,      0,   0,   0,   0,   0,   0
          0,   0, epn,   0,      0,   0,   0,   0,   0,   0
          0,   0,  -1,   0,      0,   0,   0,   0,   0,   0
          0,   0,   0,   0,      0,   0,   0,   0,   0,   0
          0,   0,   0,   0,      0,   0,   0,   0,   0,   0
         -1,   0,   0,   0,      0,   0,   0,   0,   0,   0
          0,  -1,   0,   0,      0,   0,   0,   0,   0,   0
          0,   0,   0,   0,      0,   0,   0,   0,   0,   0
          0,   0,   0,   0,      1,   0,   0,   0,   0,   0
          0,   0,   0,   0,      0,   1,   0,   0,   0,   0
          0,   0,   0,   0,      0,   0,   1,   0,   0,   0
          0,   0,   0,   0,      0,   0,   0,   1,   0,   0
          0,   0,   0,   0,      0,   0,   0,   0,   1,   0
          % NEW for CS
          0,   0,   0,   1,      0,   0,   0,   0,   0,   1];

BB = [    0,   0,   0,   0,      0,   0,   0,   0,   0,   0
          0,   0,   0,   0,      0,   0,   0,   0,   0,   0
      epn-1,   0,  -1,   0,      0,   0,   0,   0,   0,   0
       -psi,   0,   0,   0,      0,   0,   0,   0,   0,   0
        alf,   0,   0,   0,      0,   0,   0,   0,   0,   0
          0,   0,   0,   0,      0,   0,   0,   0,   0,   0
      1-del,   0,   0,   0,      0,   0,   0,   0,   0,   0
          0,   1,   0,   0,      0,   0,   0,   0,   0,   0
          0,   0,   0,   0,      0,   0,   0,   0,   0,   0
          0,   0,   0,   0,      0,   0,   0,   0,   0,   0
          0,   0,   0,   0,      0,   0,   0,   0,   0,   0
          0,   0,   0,   0,      0,   0,   0,   0,   0,   0
          0,   0,   0,   0,      0,   0,   0,   0,   0,   0
          0,   0,   0,   0,      0,   0,   0,   0,   0,   0
          0,   0,   0,   0,      0,   0,   0,   0,   0,   0];

cc52 = (1-alf)*Omg;
cc62 = sig*Lam^2/((1-sig)*H^2) - 1;
cc87 = gam*R*KoN;
CC = [  CoY,   0, IoY,    0,CeoY,   0,   0,    0,   -1
          0,   0,   0,    0,  -1,   0,   0,    0,    0
          0,   0,   0,    0,   0,   0,  -1,epn-1,1-epn
          0,   0, psi,    0,   0,   0,   0,    0,    0
          0,cc52,   0,    0,   0,   0,   0,    0,   -1
         -1,cc62,   0,    0,   0,   0,   0,   -1,    1
          0,   0, del,    0,   0,   0,   0,    0,    0
          0,   0,   0,    0,   0,   0,cc87,    0,    0
          0,   0,   0,phipi,   0,  -1,   0,    0, phiy
          0,   0,   0,    0,   0,   0,   0,    0,   -1
         -1,   0,   0,    0,   0,   0,   0,    0,    0
          0,   0,  -1,    0,   0,   0,   0,    0,    0
          0,   0,   0,   -1,   0,   0,   0,    0,    0
          0,   0,   0,    0,   0,  -1,   0,    0,    0
          0,   0,   0,    0,   0,   0,  -1,    0,    0];

DD = [   0,   0, GoY,   0,   0,   0
         0,   0,   0,   0,   0,   0
         0,   0,   0,   0,   0,   0
         0,   0,   0,   0,   0,   0
         1,   0,   0,   0,   0,   0
         0,   0,   0,   0,   1,   0
         0,   0,   0,   0,   0,   0
         0,   0,   0,   0,   0,   0
         0,  -1,   0,   0,   0,   0
         0,   0,   0,   0,   0,   0
         0,   0,   0,   0,   0,   0
         0,   0,   0,   0,   0,   0
         0,   0,   0,   0,   0,   0
         0,   0,   0,   0,   0,   0
         0,   0,   0,   0,   0,   0];
     
FF = [  0,  0,  0,     0,    0,  0,  0,  0,  0,  0
        0,  0,  0,     0,    0,  0,  0,  0,  0,  0
        0,  0,  0,     0,    0,  0,  0,  0,  0,  0
        0,  0,  0,     0,    0,  0,  0,  0,  0,  0];
    
GG = [  0,  0,  0,-1/sig,    0,  0,  0,  0,  0,  0
       nu,-nu, nu,     1,    0,  0,  0,  0,  0,  0
        0,  0,  0,     0,    0,  0,  0,  0,  0,  0
        0,  0,  0,     1,    0,  0,  0,  0,  0,  0];
       
HH = [  0,  0,  0,     0,    0,  0,  0,  0,  0,  0
        0,  0,  0,     0,    0,  0,  0,  0,  0,  0
        0,  0,  0,     0,    0,  0,  0,  0,  0,  0
        0,  0,  0,     0,    0,  0,  0,  0,  0,  0];
  
JJ = [ -1, Lam,  0,  0,  0,  0,  0,   0,  0
        0,   0,  0,  0,  0,  0,  0,   0,  0
        0,   0,  0, -1,  0,  0,  0,-kap,  0
        0,   0,  0,  0,  0,  1,  0,   0,  0];
  
KK = [  1,-Lam,  0,  0,  0,  0,  0,   0,  0
        0,   0,  0,  0,  0,  0, -1,   0,  0
        0,   0,  0,bet,  0,  0,  0,   0,  0
        0,   0,  0,  1,  0,  0,  0,   0,  0];
    
LL = [   0,    0,    0,    0,   -1,    0
         0,    0,    0,    0,    0,    0
         0,    0,    0,    0,    0,    0
         0,    0,    0,    0,    0,    0];
     
MM = [   0,    0,    0,    0,    1,    0
         0,    0,    0,    0,    0,    1
         0,    0,    0,   -1,    0,    0
         0,    0,    0,    0,    0,    0];
     
NN = [ rhoa,    0,    0,    0,    0,    0
          0, rhov,    0,    0,    0,    0
          0,    0, rhog,    0,    0,    0
          0,    0,    0, rhoc,    0,    0
          0,    0,    0,    0, rhoe,    0
          0,    0,    0,    0,    0, rhox];


%% Setting the options for Uhlig's solve2.m:

[l_equ,m_states] = size(AA);
[l_equ,n_endog ] = size(CC);
[l_equ,k_exog  ] = size(DD);

DISPLAY_IMMEDIATELY=1; % gives an error message if there is no solution
MANUAL_ROOTS=0;		   % default value
IGNORE_VV_SING = 1;    % default value
PROBLEM=0;             % binary variable if there is a problem in finding a solution PROBLEM=1

TOL = .000001;         % Roots smaller than TOL are regarded as zero.
                       % Complex numbers with distance less than TOL are regarded as equal.
  

%% Starting the calculations:
solve2;

end