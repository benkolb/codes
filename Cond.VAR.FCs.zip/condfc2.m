
function [polv1 polv2 Ycfc] = condfc2(Y,bet,Yt1,Yt2,c,k,post1,post2,posp1,posp2,fhor,zerb,graph,nam)

% Creates forecasts for an SVAR conditional on a specified path of two of
% the series in that SVAR. Specifically, it gives the required series of
% orthogonal shocks to two of the series in order to obtain a specified
% path in two other series.
% Requires the function VAR_gen.
%
% Usage:   [polv1 polv2 Ycfc] = condfc2(Y,bet,Yt1,Yt2,c,k,post1,post2,...
%                                       posp1,posp2,fhor,zerb,graph)
%
% Inputs:  Y     - original data set in format (Time x # vars)
%          bet   - structural coefficient matrix (beta)
%          Yt1   - vector containing the desired path of the target var 1
%          Yt2   - vector containing the desired path of the target var 2
%          c     - 1 if bet contains a constant, 2 if bet contains both
%                  constant and trend, 0 else
%          k     - # lags
%          post1 - position of the target var 1 (whose path is given) in Y
%          post2 - position of the target var 2 (whose path is given) in Y
%          posp1 - position of the policy var 1 (whose innovations cause
%                  the desired path in the target var) in Y
%          posp2 - position of the policy var 2 (whose innovations cause
%                  the desired path in the target var) in Y
%          fhor  - forecast horizon, default is fhor = 10
%          zerb  - set to 1 if the orginal beta matrix contains zero
%                  elements. In this case the input for bet should be the
%                  correctly specified beta matrix for TWO-STEP FORECASTS.
%          graph - plot results if graph = 1 (default is no graph)
%          nam   - structure containing strings with variable names for
%                  plotting (optional)
% Outputs: Ycfc  - forecast of all vars cond. on policy variable chosen as
%                  to obtain desired path in target var
%          polv1 - shocks to policy var 1 required to obtain target vars
%          polv2 - shocks to policy var 2 required to obtain target vars
%
% Example: Imagine you have a 4-variable SVAR with GDP growth, inflation,
%          money growth and interest rates (Y = [dgdp, pi, dM2, r]).
%          Assume the SVAR includes a constant and 3 lags and "beta"
%          contains the estimated coefficient matrix. Then
%
%          [Yf pv1 pv2] = condfc(Y,beta,4*ones(1,10),2*ones(1,10),...
%                                1,3,1,2,3,4,10,0)
%
%          will output you the shocks to the policy variable (here 3 and 4,
%          i.e. dM2 and r) necessary to obtain a growth rate of GDP of 4
%          percent and an inflation rate of 2 percent for the next 10
%          periods. No graph will be plotted.
%
% Issues: Note that these forecasts are subject to the Lucas critique, as
%         they assume that agents do not update their beta to form new
%         forecasts!
% See also Baumeister, Christiane and Lutz Kilian (2012). Real-Time
% Analysis of Oil Price Risks Using Forecast Scenarios. Working Papers
% 12-1, Bank of Canada.
% by B.Kolb (02/02/14)

if size(Y,1) < size(Y,2)
    Y = Y';
end

[Y X] = VAR_gen(Y,c,k);  % create regressor matrix using VAR_gen.m

% make two-step forecasts in case of zeros in orig. beta matrix
if zerb == 1
    Y   = Y(2:end,:);
    X   = X(1:end-1,:);
end

[T n] = size(Y);          % # variables and # periods
TT    = T + fhor;         % # overall periods
dYt1  = zeros(1,fhor);    % deviations of fc'd target 1 to desired one
dYt2  = zeros(1,fhor);    % deviations of fc'd target 2 to desired one

% pre-allocate regressor matrix
Xante = zeros(TT,size(X,2)); Xante(1:T,:) = X;
if     c == 1
    Xante(:,1)=1;
elseif c == 2
    Xante(:,1)=1; Xante(:,2)=1:TT;
end

Xpost = Xante;                         % regressor matrix (post shocks)
polv1 = zeros(1,fhor);                 % path of shock 1 to hit targets
polv2 = zeros(1,fhor);                 % path of shock 2 to hit targets
Ycfc  = zeros(TT,n); Ycfc(1:T,:) = Y;  % conditional forecasts of Y
pos1  = k*(posp1-1)+c+1;               % position of pol. var. 1 in beta
pos2  = k*(posp2-1)+c+1;               % position of pol. var. 2 in beta
% This loop assumes that agents do NOT update their beta matrix even when
% confronted with very large shocks (subject to Lucas critique)!
for i=1:fhor;
    dYt1(i)  = Yt1(i)-Xante(T+i-1,:)*bet(:,post1); % diff. uncond. FC & target for var 1
    dYt2(i)  = Yt2(i)-Xante(T+i-1,:)*bet(:,post2); % diff. uncond. FC & target for var 2
    
    % shocks required to hit target:
    % solve the following equation: y1=b11*x1+b21*x2 and y2=b12*x1+b22*x2 to
    % x1=(b21*y2-b22*y1)/(b12*b21-b11*b22) and
    % x2=(b12*y1-b11*y2)/(b12*b21-b11*b22)
    polv1(i) = (bet(pos2,post1)*dYt2(i) - bet(pos2,post2)*dYt1(i)) / ...
        (bet(pos1,post2)*bet(pos2,post1) - bet(pos1,post1)*bet(pos2,post2));
    polv2(i) = (bet(pos1,post2)*dYt1(i) - bet(pos1,post1)*dYt2(i)) / ...
        (bet(pos1,post2)*bet(pos2,post1) - bet(pos1,post1)*bet(pos2,post2));
    
    % get updated regressor matrix X*(T)
    Xpost(T+i-1,:)    = Xante(T+i-1,:);
    Xpost(T+i-1,pos1) = Xante(T+i-1,pos1)+polv1(i);
    Xpost(T+i-1,pos2) = Xante(T+i-1,pos2)+polv2(i);
    
    Ycfc(T+i,:)      = Xpost(T+i-1,:)*bet;      % Y*(T+1)
    if k >= 2
        Xante(T+i,linspace(c+2,(n-1)*k+c+2,n)) = ...
            Xante(T+i-1,linspace(c+1,(n-1)*k+c+1,n));
    end
    Xante(T+i,linspace(c+1,(n-1)*k+c+1,n)) = Ycfc(T+i,:);
end

% plot
if  nargin >= 13 && graph == 1 
    figure('Name','Series plus cond. forecast')
    for i = 1:n
        subplot(floor(n/3),ceil(n/floor(n/3)),i);
        plot(1:TT,Ycfc(:,i),'b--'); hold on; plot(T+1:TT,Ycfc(T+1:end,i),'k'); hold off;...
            if nargin == 14
            title(nam(i));
            else
            title(['Series #',num2str(i)]);
            end
        if i==1, legend('data','cond. FC','Location','Northwest'), end
    end
else
    return
end
