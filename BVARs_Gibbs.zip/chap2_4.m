
% Code to redo example 4 from chapter 2 in Blake/Mumtaz (BoE, 2014)
% Using dummy observation priors
% by Benedikt Kolb, June 2016


%% Housekeeping
clear; close all;
rng(42);


%% Load data and create Y and X
dat       = xlsread('data\datain.xls');
Y         = dat(3:end,:);
[T, nvar] = size(Y);
X         = [ones(T,1) dat(2:end-1,:) dat(1:end-2,:)];
pnam      = {'US GDP growth','US inflation'};
tim       = 1948.75:0.25:2014;
spos      = 1; % position of variable to be shocked (in [1, nvar])


%% set Gibbs sampler options and pre-allocate
ndraw = 5000; % # draws (after burn-in); default: 5000
nburn = 5000; % # burn-in draws; default: 5000
ndet  = 1;      % # deterministic regressors
nl    = 2;     % # lags
hor   = 60;    % horizon for structural IRFs
fhor  = 12;    % forecast horizon
nb    = (nl*nvar+ndet)*nvar;  % # elements in b vector !!W/O DETERM COEFF!!
% arrays to store draws and statistics of interest
bdraw = NaN(ndraw, nb);
fdraw = NaN(ndraw, fhor, nvar); % forecast
irfs  = NaN(ndraw, hor-nl, nvar); % response to (structural) shock


%% Priors
% for Independent Normal Wishart prior, use Minnesota prior with L2=1
% lambdas for Minnesota prior in Blake/Mumtaz (see p33 of their script):

% prior for H (uses data twice; discouraged: better presample!)
s = NaN(nvar,1);
for kk = 1:nvar
    yy = Y(:,kk); xx = X(:,[1 kk+1]);
    bb = (xx'*xx)\(xx'*yy); % use AR(1)
    s(kk) = sqrt((yy-xx*bb)'*(yy-xx*bb)/(size(yy,1)-2))';
end

% data mean
mu = mean(Y);

% Minnesota prior parameters (Blake/Mumtaz p. 49)
tau   = 0.1; % controls prior on own first lags
d     = 1;   % decay for higher lags
c     = 1;   % prior for the constant
L     = 1;   % sum of coefficients unit roots
delta = 1;   % cointegration prior

% dummy observations first lag
Yd1 = [s(1)/tau 0;
       0        s(2)/tau];
Xd1 = [0 s(1)/tau 0        0 0;
       0 0        s(2)/tau 0 0];

% dummy observations second lag
Yd2 = [0 0;
       0 0];
Xd2 = [0 0 0 s(1)/tau*2^d  0;
       0 0 0 0             s(2)/tau*2^d ];

% dummy observations constants
Yd3 = [0  0;
       0  0];
Xd3 = [1/c 0 0 0 0;
       1/c 0 0 0 0];

% dummy observations sum of coefficient (unit root)
Yd4 = [L*mu(1) 0;
       0       L*mu(2)];
Xd4 = [0 L*mu(1) 0       L*mu(1) 0;
       0 0       L*mu(2) 0       L*mu(2)];

% dummy observations common stochastic trend
Yd5 = [delta*mu(1) delta*mu(2)];
Xd5 = [delta delta*mu(1) delta*mu(2) delta*mu(1) delta*mu(2)];

% dummy observations covariance matrix
Yd6 = [s(1) 0;
       0    s(2)];
Xd6 = [0 0 0 0 0;
       0 0 0 0 0];

% new data augmented by dummy observations
Ys = [Y; Yd1; Yd2; Yd3; Yd4; Yd5; Yd6];
Xs = [X; Xd1; Xd2; Xd3; Xd4; Xd5; Xd6];
Ts = size(Xs,1);


%% Starting values
bOLS      = (Xs'*Xs)\(Xs'*Ys);
res       = Ys - Xs*bOLS;
Sig       = (res'*res)/Ts;


% ii=1;
% break


%% Gibbs sampler
wb = waitbar(0,'Gibbs sampling...');

for ii = 1:nburn+ndraw
    M = reshape(bOLS,nvar*(nvar*nl+ndet),1);
    V = kron(Sig,eye(nvar*nl+ndet)/(Xs'*Xs));
    % draw beta
    b    = M + chol(V)'*randn(1,nvar*(nvar*nl+1))';
    res  = Ys - Xs*reshape(b,nvar*nl+1,nvar);
    scl  = res'*res;
    % draw sigma
    aux = NaN(Ts,length(scl));
    for iw = 1:Ts
        aux(iw,:) = (chol(eye(nvar)/scl)'*randn(length(scl),1))';
    end
    Sig = eye(nvar)/(aux'*aux);
    
    if ii > nburn
        bdraw(ii-nburn,:) = b;
        % get structural impulse responses via Cholesky
        ep = zeros(hor,nvar); ep(nl+1,spos) = -1; % shock impulse
        yhat = zeros(hor,nvar);
        for hh = 3:hor
            reg        = [1 yhat(hh-1,:) yhat(hh-2,:)]; % not automised yet!
            yhat(hh,:) = reg*reshape(b,nb/nvar,nvar)  ...
                + ep(hh,:)*chol(Sig);
        end
        irfs(ii-nburn,:,:)  = yhat(nl+1:end,:);
        
        % forecast
        fore = NaN(fhor+nl,nvar);
        fore(1:2,:) = Y(end-1:end,:);
        for ff = nl+1:fhor+nl
            reg        = [1 fore(ff-1,:) fore(ff-2,:)]; % not automised yet!
            fore(ff,:) = reg*reshape(b,nb/nvar,nvar)  ...
                + randn(1,nvar)*chol(Sig);
        end
        fdraw(ii-nburn,:,:) = fore(nl+1:end,:);
    end
    waitbar(ii/(ndraw+nburn));
end


%% Plot IRFs
TT = 1:hor-nl;
pc = prctile(irfs,[50, 16, 84],1);
figure('name','Impulse responses to structural shock')
for pp = 1:numel(pnam)
    subplot(2,2,pp)
    plot(TT,pc(1,:,pp),'b',TT,pc(2,:,pp),'b--',TT,pc(3,:,pp),'b--');
    hold on;
    plot(TT,zeros(hor-nl,1),'r')
    title(pnam{pp})
    axis tight
    if pp==2; legend('50%','16/84%','Location','SouthEast'); end
end


%% Plot forecast
figure('name','Forecast of the variables')
for pp = 1:numel(pnam)
    fc = prctile(squeeze(fdraw(:,:,pp)),[5 16.7 50 83.3 95],1)';
    Yp = [repmat(Y(:,pp),1,size(fc,2)); fc];
    subplot(1,2,pp)
    plot(tim,Yp)
    xlim([1995 2015])
    title(pnam{pp})
    if pp==1; legend('5%','16.7%','50%',...
            '83.3%','95%','Location','SouthWest'); end
end




