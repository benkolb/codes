
% Example 1: Maximises the likelihood of a New 
% Keynesian model with a financial accelerator over 
% one parameter to illustrate the use of the Kalman 
% filter. 
% This code is available under 
% http://www.bkolb.eu/codes/kalman_filter
% by Benedikt Kolb, Sept. 2015

clear all; clc;

%% Load data, write data vector and the model's var-cov matrix
dat = open('dat_full.mat'); % data come as [Y C I P R S]
y   = dat.dy;
[~,nd] = size(y);

% Theta gives the initial parameter values; their meaning does not matter 
% here.
Theta = [0.99,0.9728,0.025,0.75,2,1.5,0.125,0.5,0.3,0.9,0.5,0.5,0.5, ...
         0.5,0.5,0.0625,0.0625,0.0625,0.0625,0.0625,0.0625]';
Sigma = diag([Theta(16),...  % technology shock
              Theta(17),...  % monetary policy shock
              Theta(18),...  % gvt spending shock
              Theta(19),...  % preference shock
              Theta(20),...  % shock to financial accelerator
              Theta(21)]);   % xi
          
% Set size of measurement error as a scalar (the higher it is, the less 
% you trust the fit of your observables to model variables)
meas_err = 0.5;
R = eye(nd)*meas_err;

% H, matching observables from dy into measurement equation
ns      = 16;     % # states in model
H       = zeros(nd,ns);
H(1,5)  = 1; % Y = y(t)
H(2,6)  = 1; % C = c(t)
H(3,7)  = 1; % I = i(t)
H(4,8)  = 1; % P = pi(t)
H(5,9)  = 1; % R = rn(t)
H(6,10) = 1; % S = cs(t)


%% Maximum likelihood estimation
LB = Theta*0.8;   % lower bound
UB = Theta*1.25;  % upper bound
IV = Theta;       % initial value
options = optimset('Algorithm','interior-point',...
                   'Display','iter','TolFun',1e-6);
meas_err = R;

%% Calculate model likelihood at initial values for Theta
[PP,QQ,~,~,NN,PROBLEM] = uhligsolve(Theta); % use Uhlig (1999) code

% prepare Kalman filter
F = [PP QQ*NN; zeros(size(NN,1),size(PP,2)) NN];
G = [QQ*Sigma; Sigma];

% obtain model likelihood
[L_init ~] = kalmanfilter(y,F,G,H,R);


%% Maximum likelihood estimation of Theta
[Theta_ML negL_MLE] = fmincon(@(Theta) model_solve(Theta,y,Sigma,H,R),...
            IV,[],[],[],[],LB,UB,[],options);

% show results
disp('Value of Theta that maximises likelihood:')
disp(Theta_ML)
disp('Initial vs maximised likelihood:')
disp([L_init -negL_MLE])
