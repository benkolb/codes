
function [L, x, Sigma] = kalmanf_xt(y,A,Q,C,R,Sg0)

% Kalman filter including initialisation, returning also the estimates of
% unobservable states and prediction error.
% For the following state-space model:
%      x(t) = A   *x(t-1) + u(t),    u(t)~N(0,Q)
%      y(t) = C(t)*x(t-1) + e(t),    e(t)~N(0,R)
% Note: Code returns "Inf" if MSE of forecast is not positive semidefinite.
%
% Usage:  [L, x, Sigma] = kalmanf_xt(y,A,Q,C,R,Sg0)
%
% Input:  y:   vector of observables
%         A,C: matrices of the model in state-space form
%         Q,R: variance-covariance matrix of shock to transition and
%              measurement equation, respectively
%         Sg0: Starting value for prediction error matrix Sigma
%
% Output: L:     log likelihood of the model
%         x:     estimates for the unobservable states x(t), (nobs x T)
%         Sigma: estimate of prediction error (nobs x T)
%
% by Benedikt Kolb, March 2015

%% Predefine matrices
T     = size(y,1);
nreg  = size(Q,1);
x     = zeros(nreg,T);
Sigma = zeros(nreg,nreg,T);
Omega = zeros(T,1);

%% Initialisation
L = -T/2*log(2*pi);
Sigma(:,:,1) = Sg0;

%% Kalman Filter
for t=1:T
    
    v = y(t) - C(t,:)*x(:,t);
    
    % likelihood equations
    Omega(t) = C(t,:)*(Sigma(:,:,t)+Q)*C(t,:)' + R;
    
    if det(Omega(t))<= 0;
        L     = -Inf;
        return;
    end
    
    % log likelihood function
    L = L-log(Omega(t))/2-v^2/(2*Omega(t));
    
    % Kalman gain
    K = (A*Sigma(:,:,t)*A' + Q)*C(t,:)'/Omega(t);
    
    % updating equations
    x(:,t+1) = A*x(:,t) + v*K;
    Sigma(:,:,t+1) = A*Sigma(:,:,t)*A' + Q - K*Omega(t)*K';
    
end

% correct for initial values
x  =  x(:,2:T+1);
Sigma = Sigma(:,2:T+1);

end
