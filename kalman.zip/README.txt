
This folder contains some notes on the Kalman filter (algorithm, derivations and two examples). It is available under http://www.bkolb.eu/codes/kalman.zip. 
By Benedikt Kolb, March 2015.

This folder contains the following files code files:
==========
example1.m: Use the KF to maximise the likelihood of a New Keynesian model with a financial accelerator, given some observables. 

uhligsolve.m: Routine to get the state-space form of the NK model.

solve2.m: Routine by Harald Uhlig to solve the model, see Uhlig (1997).

kalmanfilter.m: Routine to obtain likelihood and matrix of estimated states by the Kalman filter.

kalmanfilter_dense.m: Same as kalmanfilter, but with less equations in the KF algorithm.

kalmanfilter_extensive.m: Same as kalmanfilter, but with more equations in the KF algorithm.

----------

example2.m: Use the KF to obtain a measure of time-varying
Taylor rule coefficients for US data 82Q1-07Q2.

TR_US_data.csv: Data for example2.m

==========

For comments, contact me at benedikt@bkolb.eu. Enjoy!
