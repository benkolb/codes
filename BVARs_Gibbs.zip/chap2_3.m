
% Code to redo example 3 from chapter 2 in Blake/Mumtaz (BoE, 2014)
% Using steady-state (long-run) priors
% by Benedikt Kolb, June 2016


%% Housekeeping
clear; close all;
rng(42);


%% Load data and create Y and X

dat       = xlsread('data\datain.xls');
Y         = dat(3:end,:);
[T, nvar] = size(Y);
X         = [ones(T,1) dat(2:end-1,:) dat(1:end-2,:)];
pnam      = {'US GDP growth','US inflation'};
tim       = 1948.75:0.25:2021.5;
spos      = 1; % position of variable to be shocked (in [1, nvar])



%% set Gibbs sampler options and pre-allocate
ndraw =  5000; % # draws (after burn-in); default: 5000
nburn =  5000; % # burn-in draws; default: 5000
ndet  = 0;      % # deterministic regressors
nl    = 2;     % # lags
hor   = 60;    % horizon for structural IRFs
fhor  = 42;    % forecast horizon
nb    = nl*nvar*nvar;  % # elements in b vector !!W/O DETERM COEFF!!
% arrays to store draws and statistics of interest
bdraw = NaN(ndraw, nb);
Hdraw = NaN(ndraw, nb);
mdraw = NaN(ndraw, nb);
fdraw = NaN(ndraw, fhor, nvar); % forecast
irfs  = NaN(ndraw, hor-nl, nvar); % response to (structural) shock


%% Priors
% for Independent Normal Wishart prior, use Minnesota prior with L2=1
% lambdas for Minnesota prior in Blake/Mumtaz (see p33 of their script):
L1=1;
L2=1;
L3=1;
L4=1;
l2 = [0,1]; % pointer for L2 (on every for 2,4,6,8, but not 1,3,5,7)

% prior for b
b0 = [1 0 0 0 0 1 0 0]'; % AR(1) params = RW !!W/O DETERM COEFF!!

% prior for H (uses data twice; discouraged: better presample!)
s = NaN(nvar,1);
for kk = 1:nvar
    yy = Y(:,kk); xx = X(:,[1 kk+1]);
    bb = (xx'*xx)\(xx'*yy); % use AR(1)
    s(kk) = sqrt((yy-xx*bb)'*(yy-xx*bb)/(size(yy,1)-2))';
end

% prior for H=var(b)
H0 = zeros(nb,nb);
for hh = 1:nb
    bas = floor(hh/(nvar*nl)-1e-10)+1;
    idx = mod(hh,nvar*nl); % use recurrence after nvar*nl+1!
    if idx==0;   idx = nvar*nl;   end % fix mod output
    
        bas2 = floor(idx/(nvar+1))+ndet+1;
        idx2 = 2-mod(idx,nvar);
        if idx2 == 1; CL2 = L2; else CL2 = 1; end
        H0(hh,hh) = (s(bas)*L1*L2^l2(idx2)/(s(idx2)*bas2^L3))^2;
end

% prior scale matrix (IW) for VAR covariance sigma^2
S0 = eye(nvar);
% prior degrees of freedom of IW
a0 = nvar+1;

% priors for long-run mean
M0 = [1 1];           % prior mean
V0 = eye(nvar)*0.001; % prior variance


%% Starting values
bOLS      = (X'*X)\(X'*Y);
Comp      = [bOLS(2:nvar*nl+1,:)';eye(nvar*(nl-1),nvar*nl)];
C         = zeros(size(Comp,1),1);
C(1:nvar) = bOLS(1,:)';
mu        = (eye(size(Comp,1))-Comp)\C;
res       = Y - X*bOLS;
Sig       = (res'*res)/T;


% ii=1;
% break


%% Gibbs sampler
wb = waitbar(0,'Gibbs sampling...');

for ii = 1:nburn+ndraw
    
    % demean using mu and calculate bOLS
    Y0   = dat - repmat(mu(1:nvar)',size(dat,1),1);
    X0   = [Y0(2:end-1,:) Y0(1:end-2,:)];
    Y0   = Y0(nl+1:end,:);
    bOLS = vec((X0'*X0)\(X0'*Y0));

    % draw b from normal distribution
    Ms = (eye(nb)/H0 + kron(eye(nvar)/Sig,X0'*X0))\ ...
        (H0\b0 + kron(eye(nvar)/Sig,X0'*X0)*bOLS);
    Vs = (eye(nb)/H0 + kron(eye(nvar)/Sig,X0'*X0))\eye(nb);
    
%     % check for stability
%     chck = 2;
%     while chck > 1
%         b   = Ms + chol(Vs)'*randn(1,nb)';
%         bet = reshape(b,nb/nvar,nvar);
%         Comp = [bet(1:nvar*nl,:)';eye(nvar*(nl-1),nvar*nl)];
%         chck = max(abs(eig(Comp))); % Companion form "stable"?
%     end

    % use the three lines below instead of stability check
    b    = Ms + chol(Vs)'*randn(1,nb)';
    bet  = reshape(b,nb/nvar,nvar);
    Comp = [bet(1:nvar*nl,:)'; eye(nvar*(nl-1),nvar*nl)];

    
    % draw Sigma from IW distribution
    res = Y0 - X0*bet;
    scl = S0 + res'*res;
    aux = NaN(T+a0,length(scl));
    for iw = 1:T+a0
        aux(iw,:) = (chol(eye(nvar)/scl)'*randn(length(scl),1))';
    end
    Sig = eye(nvar)/(aux'*aux);

    % draw mu
    Y1 = Y - X(:,2:end)*bet;
    % below: not generalised, only for nl=2!
    U = [eye(nvar); bet(1:nvar,:)'; bet(nvar+1:nvar*nl,:)'];
    
    D = [ones(T,1), -ones(T,nl)];
    vstar1 = eye(nvar)/(U'*kron(D'*D,eye(nvar)/Sig)*U+eye(nl)/V0);
    mstar1 = vstar1*(U'*vec(Sig\Y1'*D)+V0\M0');
    mu     = mstar1+(randn(1,nvar)*chol(vstar1))';
    
    % save draws and structural impulse response
    if ii > nburn
        bdraw(ii-nburn,:) = b;
        Hdraw(ii-nburn,:) = diag(H0);
        % get structural impulse responses via Cholesky
        ep = zeros(hor,nvar); ep(nl+1,spos) = -1; % shock impulse
        yhat = zeros(hor,nvar);
        for hh = 3:hor
            reg        = [yhat(hh-1,:) yhat(hh-2,:)]; % not automised yet!
            yhat(hh,:) = reg*reshape(b,nb/nvar,nvar)  ...
                + ep(hh,:)*chol(Sig);
        end
        irfs(ii-nburn,:,:)  = yhat(nl+1:end,:);
        
        % forecast
        fore = NaN(fhor+nl,nvar);
        mux  = repmat(mu,nl,1);
        C    = (eye(size(Comp,1))-Comp)*mux;
        fore(1:2,:) = Y(end-1:end,:);
        for ff = nl+1:fhor+nl
            reg        = [fore(ff-1,:) fore(ff-2,:)]; % not automised yet!
            fore(ff,:) = C(1:nvar)' + reg*reshape(b,nb/nvar,nvar)  ...
                + randn(1,nvar)*chol(Sig);
        end
        fdraw(ii-nburn,:,:) = fore(nl+1:end,:);
    end
    waitbar(ii/(ndraw+nburn));
end

close(wb)


%% Plot IRFs
TT = 1:hor-nl;
pc = prctile(irfs,[50, 16, 84],1);
figure('name','Impulse responses to structural shock')
for pp = 1:numel(pnam)
    subplot(2,2,pp)
    plot(TT,pc(1,:,pp),'b',TT,pc(2,:,pp),'b--',TT,pc(3,:,pp),'b--');
    hold on;
    plot(TT,zeros(hor-nl,1),'r')
    title(pnam{pp})
    axis tight
    if pp==2; legend('50%','16/84%','Location','SouthEast'); end
end


%% Plot forecast
figure('name','Forecast of the variables')
for pp = 1:numel(pnam)
    fc = prctile(squeeze(fdraw(:,:,pp)),[5 16.7 50 83.3 95],1)';
    Yp = [repmat(Y(:,pp),1,size(fc,2)); fc];
    subplot(1,2,pp)
    plot(tim,Yp)
    xlim([1995 2022])
    title(pnam{pp})
    if pp==1; legend('5%','16.7%','50%',...
            '83.3%','95%','Location','SouthWest'); end
end
