
function [ys,check] = NKJFV_steadystate(ys,exo)
% function [ys,check] = NK_baseline_steadystate(ys,exo)
% computes the steady state for the NK_baseline.mod and uses a numerical
% solver to do so
% Inputs:
% - ys [vector] vector of initial values for the steady state of
% the endogenous variables
% - exo [vector] vector of values for the exogenous variables
%
% Output:
% - ys [vector] vector of steady state values fpr the the endogenous variables
% - check [scalar] set to 0 if steady state computation worked and to
% 1 of not (allows to impos restriction on parameters)

global M_

% read out parameters to access them with their name
NumberOfParameters = M_.param_nbr;
for ii = 1:NumberOfParameters
    paramname = deblank(M_.param_names(ii,:));
    eval([ paramname ' = M_.params(' int2str(ii) ');']);
end
% initialize indicator
check = 0;

%% Enter model equations here
options=optimset(); % set options for numerical solver

% the steady state computation follows FV (2006), section 4.1
PI=PIbar;
u=1;
q=1;
d=1;
phi=1;
m=0;
zeta=1;
mu_z=exp(LamYd);
mu_I=exp(Lammu);
mu_A=exp(LamA);

%set the parameter Lamx
Lamx=mu_z;

%set the parameter gam1
gam1=mu_z*mu_I/bet-(1-del);
if gam1<0 % parameter violates restriction; Preventing this cannot be implemented via prior restriction as it is a composite of different parameters and the valid prior region has unknown form
    check=1; %set failure indicator
    return; %return without updating steady states
end

r=1*gam1;
R=1+(PI*mu_z/bet-1);

%set Rbar
Rbar=R;

PIstar=((1-tetp*PI^(-(1-ela)*(1-chi)))/(1-tetp))^(1/(1-ela));
PIstarw=((1-tetw*PI^(-(1-chiw)*(1-eta))*mu_z^(-(1-eta)))/(1-tetw))^(1/(1-eta));

mc=(ela-1)/ela*(1-bet*tetp*PI^((1-chi)*ela))/(1-bet*tetp*PI^(-(1-ela)*(1-chi)))*PIstar;
w=(1-alf)*(mc*(alf/r)^alf)^(1/(1-alf));
wstar=w*PIstarw;
vp=(1-tetp)/(1-tetp*PI^((1-chi)*ela))*PIstar^(-ela);
vw=(1-tetw)/(1-tetw*PI^((1-chiw)*eta)*mu_z^eta)*PIstarw^(-eta);
tempvaromega=alf/(1-alf)*w/r*mu_z*mu_I;

[ld,fval,exitflag]=fsolve(@(ld)(1-bet*tetw*mu_z^(eta-1)*PI^(-(1-chiw)*(1-eta)))/(1-bet*tetw*mu_z^(eta*(1+gam))*PI^(eta*(1-chiw)*(1+gam)))...
    -(eta-1)/eta*wstar/(psy*PIstarw^(-eta*gam)*ld^gam)*((1-h*mu_z^(-1))^(-1)-bet*h*(mu_z-h)^(-1))*...
    ((mu_A*mu_z^(-1)*vp^(-1)*tempvaromega^alf-tempvaromega*(1-(1-del)*(mu_z*mu_I)^(-1)))*ld-vp^(-1)*Phi)^(-1),0.25,options);
if exitflag <1
    %indicate the SS computation was not sucessful; this would also be detected by Dynare
    %setting the indicator here shows how to use this functionality to
    %filter out parameter draws
    check=1; %set failure indicator
    return; %return without updating steady states
end
disp(ld)

l=vw*ld;
k=tempvaromega*ld;
x=(1-(1-del)*(mu_z*mu_I)^(-1))*k;
yd=(mu_A/mu_z*k^alf*ld^(1-alf)-Phi)/vp;
c=(mu_A*mu_z^(-1)*vp^(-1)*tempvaromega^alf-tempvaromega*(1-(1-del)*(mu_z*mu_I)^(-1)))*ld-vp^(-1)*Phi;
lam=(1-h*bet*mu_z^(-1))*(1-h/mu_z)^(-1)/c;
F=yd-1/(1-alf)*w*ld;
f=(eta-1)/eta*wstar*PIstarw^(-eta)*lam*ld/(1-bet*tetw*mu_z^(eta-1)*PI^(-(1-chiw)*(1-eta)));
f2=psy*d*phi*PIstarw^(-eta*(1+gam))*ld^(1+gam)/(1-bet*tetw*(PI^chiw/PI)^(-eta*(1+gam))*(wstar/wstar*mu_z)^(eta*(1+gam)));

g1=lam*mc*yd/(1-bet*tetp*PI^((1-chi)*ela));
g2=ela/(ela-1)*g1;

%% end own model equations
for iter = 1:length(M_.params) %update parameters set in the file
    eval([ 'M_.params(' num2str(iter) ') = ' M_.param_names(iter,:) ';' ])
end

NumberOfEndogenousVariables = M_.orig_endo_nbr; %auxiliary variables are set automatically
for ii = 1:NumberOfEndogenousVariables
    varname = deblank(M_.endo_names(ii,:));
    eval(['ys(' int2str(ii) ') = ' varname ';']);
end