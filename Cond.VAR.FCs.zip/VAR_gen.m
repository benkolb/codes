
function [yy,xx,x] = VAR_gen(y,c,k)

% Creates matrices for VAR(k) out of given dataset
% Usage:   [yy,xx,x] = VAR_gen(y,c,k)
% Inputs:  y:  data matrix of format (TxN)
%          c:  0 no intercept or linear trend; 1 intercept; 2 intercept
%              and linear trend
%          k:  number of lags
% Outputs: yy: matrix of LHS variables
%          xx: matrix of RHS variables (ordered all lags of first 
%              variables, all lags of second variable, etc.)
%          x:  matrix of RHS variables (ordered first lag of all variables,
%              second lag of all variables etc.)
% by B.Kolb (11/12/13), based on code by L. Gambetti and F. Canova

[T N] = size(y);
yy = zeros(T-k,N); xx = zeros(T-k,N*k);
for i=1:N,
    yy(:,i)=y(k+1:T,i);
    for j=1:k,
        xx(:,k*(i-1)+j)=y(k+1-j:T-j,i);
    end;
end;
if     c==1, xx=[ones(T-k,1) xx];           % add constant and linear trend, if necessary
             z1(:,1) = xx(:,1);             % create variable for reordering in x
elseif c==2, xx=[ones(T-k,1) (1:T-k)' xx];
             z2(:,1:2) = xx(:,1:2);
end
for ij = 1:k
    zz(:,(ij-1)*N+1:N*ij) = xx(:,ij+c:k:size(xx,2));
end
if     c==0, x = zz;
elseif c==1, x = [z1 zz];
elseif c==2, x = [z2 zz];
end