
function [L x] = kalmanfilter_dense(y,F,G,H,R)

% Uses a dense Kalman filter (i.e. with fewer equations) to calculate the 
% likelihood of a model in state-space form 
%
%      states(t) = F*states(t-1) + G*e(t),  e(t)~N(0,I)    
%         obs(t) = H*states(t)   + v(t),    v(t)~N(0,R)
%
% given observables y and where H is a "matching" matrix connecting series 
% in the observables with the corresponding states.
% Note:   - The function assumes zeros as starting values for states (fits
%           log-linearised models)
%         - returns "Inf" if MSE of forecasts is not positive semidefinite 
% 
% Usage:  [L x] = kalmanfilter_dense(y,F,G,H,R)
% 
% Input:  y:   vector of observables      
%         F,G: matrices of the model in state-space form
%         H:   matrix matching observables and model variables
%         R:   variance-covariance matrix of measurement error
% 
% Output: L:   log likelihood of the model
%         x:   estimates for the unobservable states x(t), (1 x ns)
%
% By Benedikt Kolb (Sept. 2015)


%% Housekeeping
if size(y,1) > size(y,2)
    y = y';
end
[ny,T] = size(y);              % dimensions of data matrix
ns     = size(F,1);            % # state variables (exog. st. vars & shocks)


%% Intial values for the system
x     = zeros(ns,1);          % mean of log-lin'd states

Sigma = reshape( (eye((ns^2))-kron(F,F)) \ reshape(G*G',(ns^2),1) ,ns,ns); 
% uncond. var. of MSE of forecasts

% alternatively (comment out for initialising Sigma by Lyapunov equation):
% Sigma = lyapunov_symm(F,G*G',1); % requires Dynare's lyapunov.m

L     = -T*ny*log(2*pi)/2;    % initialise (log) likelihood


%% Kalman filter algorithm
for tt=1:T;  
   
   % Accumulated model log likelihood (scaled, non-determ. part of it)
   if det(H*(F*Sigma*F' + G*G')*H' + R)<= 0;
       L     = -Inf;
       return;
   else
       L     = L - (log(det(H*(F*Sigma*F' + G*G')*H' + R)) + ...
           (y(:,tt) - H*F*x(:,tt))'/(H*(F*Sigma*F' + G*G')*H' + R)...
           *(y(:,tt) - H*F*x(:,tt)))/2;
   end
   
   % Updating equations for states and their MSFE
   x(:,tt+1) = F*x(:,tt) + ...
       ((F*Sigma*F' + G*G')*H'/(H*(F*Sigma*F' + G*G')*H' + R)) * ...
       (y(:,tt) - H*F*x(:,tt)); %     x(t|t)
   Sigma     = (eye(ns) - ...
   ((F*Sigma*F' + G*G')*H'/(H*(F*Sigma*F' + G*G')*H' + R))*H) * ...
   (F*Sigma*F' + G*G');         % Sigma(t|t)
   
end

x = x(:,2:end); % only save updated states

end

