
function negL = model_solve(Theta,y,Sigma,H,R)

% Function maximum likelihood estimation. Gives the negative log likelihood
% of a model specified in "uhligsolve.m" below for parameters Theta.
% 
% Usage:  negL = model_solve(Theta,y,Sigma,H,R)
% 
% Inputs: Theta - vector of parameters
%         y     - data matrix
%         Sigma - covariance matrix of the model
%         H     - matching matrix (coeff.s of measurement equation)
%         R     - matrix of measurement error
%
% Output: negL  - negative log likelihood (needed for minimisation!)
%
% by Benedikt Kolb, Sept. 2015

[PP,QQ,~,~,NN,PROBLEM] = uhligsolve(Theta); % as in Uhlig (1999)
if PROBLEM==1 %  if 1, there's a problem for Uhlig to find solution
    negL = Inf;
    return;
end

% prepare Kalman filter
F = [PP QQ*NN; zeros(size(NN,1),size(PP,2)) NN];
G = [QQ*Sigma; Sigma];

% ns = size(PP,1) + size(NN,1);

% obtain negative (!) model likelihood
[L ~] = kalmanfilter(y,F,G,H,R);
negL = -L;

end
