
% Small didactic example for an SVAR
% Benedikt Kolb, Feb. 2015

clear all; clc; close all;
%addpath(pathdef_adapted);

%% read data
Y = csvread('example_data.csv',1,1);
Y(:,1) = log(Y(:,1)); % take log of GDP
[T N] = size(Y);

%% detrend data
tr = [ones(T,1) (1:T)'];
beta_tr = (tr'*tr)\(tr'*Y);
Yd = Y - tr*beta_tr;

%% reduced-form VAR for given lag length 2
lags = 2;
y    = Yd(lags+1:T,:);
x    = zeros(T-lags,lags*N);
for ii = 1:lags
    x(:,(ii-1)*N+1:ii*N) = Yd(lags-ii+1:T-ii,:);
end
bet  = (x'*x)\(x'*y);
sig  = (y-x*bet)'*(y-x*bet)/(T-(N+1)*lags);

%% structural-form VAR
hor  = 40;             % horizon over which IRs are calculated
invA = chol(sig)';
IRF  = zeros(hor, N, N);
for vv = 1:N
    
    response = zeros(N, hor);
    impulse = zeros(N,1);
    impulse(vv,1) = 1;
    response(:,1) = invA*impulse;
    response(:,2) = response(:,1)'*bet(1:3,:);
    
    for jj = 3:hor
        response(:,jj)=response(:,jj-1)'*bet(1:3,:)+response(:,jj-2)'*bet(4:6,:);
    end
    
    IRF(:,:,vv) = response';
end

%% compare to IRs generated with the toolbox:
VAR = VARreg(Yd,2,0);
[IRFc, invAc, IRF_optc] = VARImpResp(VAR,hor);

disp('Impulse responses from toolbox and example (first shock):')
disp(IRFc(1:5,:,1))
disp(IRF(1:5,:,1))
disp('Maximal difference between the IRFs (all three shocks):')
disp(max(IRFc(1:5,:,1)-IRF(1:5,:,1)))
disp(max(IRFc(1:5,:,2)-IRF(1:5,:,2)))
disp(max(IRFc(1:5,:,3)-IRF(1:5,:,3)))


%% plot IRFs
[h,s,v] = size(IRF);
steps = 1:1:h;
nams = {'GDP shock','defl. shock','hours shock'}; 
namv = {'(log) real GDP','GDP deflator','worked hours'};
for jj=1:s
    figure('name',nams{jj})
    for ii=1:v
        subplot(round(sqrt(N)),ceil(sqrt(N)),ii);
        plot(steps,IRF(:,ii,jj),'b','LineWidth',2);
        xlabel(namv{ii});
    end
    suptitle(nams{jj})
end


