
function diff = diff_moment(XX,params)
% Calculates the difference from target moment given certain parameterisation
% Created by Benedikt Kolb, Oct. 2014

params_names=fieldnames(params);
for ii=1:length(params_names)
    eval([params_names{ii} '=params.' params_names{ii} ';']);
end;

% load guessed value
k = XX(1);

% Calculating steady state values
a = 1;
y = k^alf;
c = k^(alf)-del*k;

% Export this difference:
diff = 1 - bet*(alf*k^(alf-1) + 1-del);
