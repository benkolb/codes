
% Code to redo example 1 from chapter 2 in Blake/Mumtaz (BoE, 2014)
% Using the Normal Inverse Wishart prior
% by Benedikt Kolb, June 2016


%% Housekeeping
clear; close all;
rng(42);


%% Load data and create Y and X

dat       = xlsread('data\datain.xls');
Y         = dat(3:end,:);
[T, nvar] = size(Y);
X         = [ones(T,1) dat(2:end-1,:) dat(1:end-2,:)];
pnam = {'US GDP growth','US inflation'};
tim  = 1948.75:0.25:2014;
spos = 1; % position of variable to be shocked (in [1, nvar])



%% set Gibbs sampler options and pre-allocate
ndraw =  5000; % # draws (after burn-in); default: 5000
nburn =  5000; % # burn-in draws; default: 5000
ndet  = 1;      % # deterministic regressors
nl    = 2;     % # lags
hor   = 60;    % horizon for structural IRFs
fhor  = 12;    % forecast horizon
nb    = (nl*nvar+ndet)*nvar;  % # elements in b vector
% arrays to store draws and statistics of interest
bdraw = NaN(ndraw, nb);
Hdraw = NaN(ndraw, nb);
fdraw = NaN(ndraw, fhor, nvar); % forecast
irfs  = NaN(ndraw, hor-nl, nvar); % response to (structural) shock


%% Priors
% for Independent Normal Wishart prior, use Minnesota prior with L2=1

% lambdas for Minnesota prior in Blake/Mumtaz (see p33 of their script):
L1=1;
L2=1;
L3=1;
L4=1;


prior_type = 'Minnesota'; %
if strcmp(prior_type,'Minnesota')
    % prior for b
    b0 = [0 1 0 0 0 0 0 1 0 0]'; % AR(1) parameters follow random walk
    
    % prior for H (uses data twice; discouraged: better presample!)
    s = NaN(nvar,1);
    for kk = 1:nvar
        yy = Y(:,kk); xx = X(:,[1 kk+1]);
        bb = (xx'*xx)\(xx'*yy); % use AR(1)
        s(kk) = sqrt((yy-xx*bb)'*(yy-xx*bb)/(size(yy,1)-2))';
    end
    
    %{
    p3 = 2^L3;
    aa = [s(1)*L4,   L1,  sqrt(1e-9),  sqrt(1e-9),  sqrt(1e-9), L1/p3, ... % six each
        sqrt(1e-9),  sqrt(1e-9),  sqrt(1e-9),  s(2)*L4, s(2)*L1/s(1),  L1, ...
        s(2)*L1/s(3), s(2)*L1/s(4), s(2)*L1/s(1)/p3, L1/p3, s(2)*L1/s(3)/p3, s(2)*L1/s(4)/p3, ...
        s(3)*L4, s(3)*L1/s(1), s(3)*L1/s(2), L1, s(3)*L1/s(4), s(3)*L1/s(1)/p3, ...
        s(3)*L1/s(2)/p3, L1/p3, s(3)*L1/s(4)/p3, s(4)*L4, s(4)*L1/s(1), s(4)*L1/s(2), ...
        s(4)*L1/s(3), L1, s(4)*L1/s(1)/p3, s(4)*L1/s(2)/p3,  s(4)*L1/s(3)/p3, L1/p3];
    
    H00 = diag(aa.^2);
    %}
    H0 = zeros(nb,nb);
    for hh = 1:nb
        bas = floor((hh-1)/(nvar*nl+1))+1;
        idx = mod(hh,nvar*nl+1); % use recurrence after nvar*nl+1!
        if idx==0;   idx = nvar*nl+1;   end % fix mod output
        % get entries for H0
        if idx==1;   H0(hh,hh) = (s(bas))^2 * L4; % constants
        else
            bas2 = floor(idx/(nvar+2))+1;
            idx2 = mod(idx+2,nvar)+1;
            if idx2 == 1; CL2 = L2; else CL2 = 1; end
            H0(hh,hh) = (s(bas)*L1*L2/(s(idx2)*bas2^L3))^2;
        end
    end
    
    % prior scale matrix (IW) for VAR covariance sigma^2
    S0 = eye(nvar);
    % prior degrees of freedom of IW
    a0 = nvar+1;
    
elseif strcmp('prior_type','Minnesota')
    
end



%% Starting values
bOLS = reshape((X'*X)\(X'*Y),[size(b0,1)*size(b0,2),1]);
% bOLS: not starting value, but short-cut
Sig  = eye(nvar);

% ii=1;
% break

%% Gibbs sampler
wb = waitbar(0,'Gibbs sampling...');

for ii = 1:nburn+ndraw
    
    % draw b from normal distribution
    Ms = (eye(nb)/H0 + kron(eye(nvar)/Sig,X'*X))...
        \(H0\b0 + kron(eye(nvar)/Sig,X'*X)*bOLS);
    Vs = (eye(nb)/H0 + kron(eye(nvar)/Sig,X'*X))\eye(nb);
    
    % check for stability
    chck = 2;
    while chck > 1
        b  = Ms + chol(Vs)'*randn(1,nb)';
        Comp = zeros(nvar*nl,nvar*nl); % Companion form of b
        Comp(nvar+1:nvar*nl,1:nvar*(nl-1)) = ...
            eye(nvar*(nl-1),nvar*(nl-1));
        temp = reshape(b,nb/nvar,nvar);
        Comp(1:nvar,1:nvar*nl)=temp(2:nvar*nl+1,1:nvar)';
        chck = max(abs(eig(Comp))); % Companion form "stable"?
    end
    
    % draw Sigma from IW distribution
    res = Y - X*reshape(b,nb/nvar,nvar);
    scl = S0 + res'*res;
    aux = NaN(T+a0,length(scl));
    for iw = 1:T+a0
        aux(iw,:) = (chol(eye(nvar)/scl)'*randn(length(scl),1))';
    end
    Sig = eye(nvar)/(aux'*aux);
    
    % save draws and structural impulse response
    if ii > nburn
        bdraw(ii-nburn,:) = b;
        Hdraw(ii-nburn,:) = diag(H0);
        % get structural impulse responses via Cholesky
        ep = zeros(hor,nvar); ep(nl+1,spos) = -1; % shock impulse
        yhat = zeros(hor,nvar);
        for hh = 3:hor
            reg        = [0 yhat(hh-1,:) yhat(hh-2,:)]; % not automised yet!
            yhat(hh,:) = reg*reshape(b,nb/nvar,nvar)  ...
                + ep(hh,:)*chol(Sig);
        end
        irfs(ii-nburn,:,:)  = yhat(nl+1:end,:);
        % forecast
        fore = NaN(fhor+nl,nvar);
        fore(1:2,:) = Y(end-1:end,:);
        for ff = nl+1:fhor+nl
            reg        = [1 fore(ff-1,:) fore(ff-2,:)]; % not automised yet!
            fore(ff,:) = reg*reshape(b,nb/nvar,nvar)  ...
                + randn(1,nvar)*chol(Sig);
        end
        fdraw(ii-nburn,:,:) = fore(nl+1:end,:);
    end
    waitbar(ii/(ndraw+nburn));
end

close(wb)


%% Plot IRFs
TT = 1:hor-nl;
pc = prctile(irfs,[50, 16, 84],1);
figure('name','Impulse responses to structural shock')
for pp = 1:numel(pnam)
    subplot(2,2,pp)
    plot(TT,pc(1,:,pp),'b',TT,pc(2,:,pp),'b--',TT,pc(3,:,pp),'b--');
    hold on;
    plot(TT,zeros(hor-nl,1),'r')
    title(pnam{pp})
    axis tight
    if pp==2; legend('50%','16/84%','Location','SouthEast'); end
end


%% Plot forecast
figure('name','Forecast of the variables')
for pp = 1:numel(pnam)
    fc = prctile(squeeze(fdraw(:,:,pp)),[5 16.7 50 83.3 95],1)';
    Yp = [repmat(Y(:,pp),1,size(fc,2)); fc];
    subplot(1,2,pp)
    plot(tim,Yp)
    xlim([1995 2015])
    title(pnam{pp})
    if pp==1; legend('5%','16.7%','50%',...
            '83.3%','95%','Location','SouthWest'); end
end
