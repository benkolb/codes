
% Code to redo example 2 from chapter 2 in Blake/Mumtaz (BoE, 2014)
% Using the Normal Inverse Wishart prior
% by Benedikt Kolb, May 2016

% To switch from example 2.2 to 2.1, change the following:
%       * set choose_example = 'ex2.1'
%       * change the prior lambdas (all to 1)
%       * set ndraws = 5000 and nburn = 5000
%       * comment out ZLB assumptions (below priors)

%% Housekeeping
clear; close all;
rng(42);


%% Load data and create Y and X
choose_example = 'ex2.2'; % 'ex2.1'

if strcmp(choose_example,'ex2.2')
    dat       = xlsread('data\dataUS.xls');
    Y         = dat(3:end,:);
    [T, nvar] = size(Y);
    X         = [ones(T,1) dat(2:end-1,:) dat(1:end-2,:)];
    pnam = {'Federal funds rate', '10-year government bond yield',...
        'unemployment rate', 'annual CPI inflation'};
    tim  = 2007+5/12:1/12:2011+12/12;
    spos = 2; % position of variable to be shocked (in [1, nvar])
elseif strcmp(choose_example,'ex2.1')
    dat       = xlsread('_data\datain.xls');
    Y         = dat(3:end,:);
    [T, nvar] = size(Y);
    X         = [ones(T,1) dat(2:end-1,:) dat(1:end-2,:)];
    pnam = {'US GDP growth','US inflation'};
    tim  = 1948.75:0.25:2014;
    spos = 1; % position of variable to be shocked (in [1, nvar])
end



%% set Gibbs sampler options and pre-allocate
ndraw =  10000; % # draws (after burn-in); default: 10000
nburn =  30000; % # burn-in draws; default: 30000
ndet  = 1;      % # deterministic regressors
nl    = 2;     % # lags
hor   = 60;    % horizon for structural IRFs
fhor  = 12;    % forecast horizon
nb    = (nl*nvar+ndet)*nvar;  % # elements in b vector
% arrays to store draws and statistics of interest
bdraw = NaN(ndraw, nb);
Hdraw = NaN(ndraw, nb);
fdraw = NaN(ndraw, fhor, nvar); % forecast
irfs  = NaN(ndraw, hor-nl, nvar); % response to (structural) shock


%% Priors
% for Independent Normal Wishart prior, use Minnesota prior with L2=1

% choose hyperparameters lambda1 to lambda4:
L1 = .1;   % lambda_1
L2 = 1;    % lambda_2 (1 for Indep. Normal Wishart, any for Minnesota)
L3 = .05;  % lambda_3
L4 = 1;    % lambda_4

% lambdas for Minnesota prior in Blake/Mumtaz: 
% L1=1;
% L2=1;
% L3=1;
% L4=1;


prior_type = 'Minnesota'; %
if strcmp(prior_type,'Minnesota')
    % prior for b
    b00 = [zeros(nvar,1) eye(nvar)*0.95 eye(nvar)*0]';
    b0 = reshape(b00,[size(b00,1)*size(b00,2),1]); % vectorise
    
    % prior for H (uses data twice; discouraged: better presample!)
    s = NaN(nvar,1);
    for kk = 1:nvar
        yy = Y(:,kk); xx = X(:,[1 kk+1]);
        bb = (xx'*xx)\(xx'*yy); % use AR(1)
        s(kk) = sqrt((yy-xx*bb)'*(yy-xx*bb)/(size(yy,1)-2))';
    end
    
 %{
    p3 = 2^L3;
    aa = [s(1)*L4,   L1,  sqrt(1e-9),  sqrt(1e-9),  sqrt(1e-9), L1/p3, ... % six each
        sqrt(1e-9),  sqrt(1e-9),  sqrt(1e-9),  s(2)*L4, s(2)*L1/s(1),  L1, ...
        s(2)*L1/s(3), s(2)*L1/s(4), s(2)*L1/s(1)/p3, L1/p3, s(2)*L1/s(3)/p3, s(2)*L1/s(4)/p3, ...
        s(3)*L4, s(3)*L1/s(1), s(3)*L1/s(2), L1, s(3)*L1/s(4), s(3)*L1/s(1)/p3, ...
        s(3)*L1/s(2)/p3, L1/p3, s(3)*L1/s(4)/p3, s(4)*L4, s(4)*L1/s(1), s(4)*L1/s(2), ...
        s(4)*L1/s(3), L1, s(4)*L1/s(1)/p3, s(4)*L1/s(2)/p3,  s(4)*L1/s(3)/p3, L1/p3];
    
    H00 = diag(aa.^2);
%}    
    H0 = zeros(nb,nb);
    for hh = 1:nb
        bas = floor((hh-1)/(nvar*nl+1))+1;
        idx = mod(hh,nvar*nl+1); % use recurrence after nvar*nl+1!
        if idx==0;   idx = nvar*nl+1;   end % fix mod output
        % get entries for H00
        if idx==1;   H0(hh,hh) = (s(bas))^2 * L4; % constants
        else
            bas2 = floor(idx/(nvar+2))+1;
            idx2 = mod(idx+2,nvar)+1;
            if idx2 == 1; CL2 = L2; else CL2 = 1; end
%             sidx(hh) = idx2;
            H0(hh,hh) = (s(bas)*L1*L2/(s(idx2)*bas2^L3))^2;
        end    
    end
    
    % prior scale matrix (IW) for VAR covariance sigma^2
    S0 = eye(nvar);
    % prior degrees of freedom of IW
    a0 = nvar+1;
    
elseif strcmp('prior_type','Minnesota')
    
end


%% Tweak: Add ZLB assumptions to prior for ex2.2 case
% enter ZLB prior assumption (R(t) will not react to other var.s)
H0(3,3) = 1e-9;  H0(4,4) = 1e-9;  H0(5,5) = 1e-9;
H0(7,7) = 1e-9;  H0(8,8) = 1e-9;  H0(9,9) = 1e-9;


%% Starting values
bOLS = reshape((X'*X)\(X'*Y),[size(b00,1)*size(b00,2),1]);
% bOLS: not starting value, but short-cut
Sig  = eye(nvar);

% ii=1;
% break


%% Gibbs sampler
wb = waitbar(0,'Gibbs sampling...');

for ii = 1:nburn+ndraw
    
    % draw b from normal distribution
    Ms = (eye(nb)/H0 + kron(eye(nvar)/Sig,X'*X))...
        \(H0\b0 + kron(eye(nvar)/Sig,X'*X)*bOLS);
    Vs = (eye(nb)/H0 + kron(eye(nvar)/Sig,X'*X))\eye(nb);
    
    % check for stability
    chck = 2;
    while chck > 1
        b   = Ms + chol(Vs)'*randn(1,nb)';
        bet = reshape(b,nb/nvar,nvar);
        Comp = [bet(2:nvar*nl+ndet,:)'; eye(nvar*(nl-1),nvar*nl)];
        chck = max(abs(eig(Comp))); % Companion form "stable"?
    end
    
    % draw Sigma from IW distribution
    res = Y - X*reshape(b,nb/nvar,nvar);
    scl = S0 + res'*res;
    aux = NaN(T+a0,length(scl));
    for iw = 1:T+a0
        aux(iw,:) = (chol(eye(nvar)/scl)'*randn(length(scl),1))';
    end
    Sig = eye(nvar)/(aux'*aux);
    
    % save draws and structural impulse response
    if ii > nburn
        bdraw(ii-nburn,:) = b;
        Hdraw(ii-nburn,:) = diag(H0);
        % get structural impulse responses via Cholesky
        ep = zeros(hor,nvar); ep(nl+1,spos) = -1; % shock impulse
        yhat = zeros(hor,nvar);
        for hh = 3:hor
            reg        = [0 yhat(hh-1,:) yhat(hh-2,:)]; % not automised yet!
            yhat(hh,:) = reg*reshape(b,nb/nvar,nvar)  ...
                + ep(hh,:)*chol(Sig);
        end
        irfs(ii-nburn,:,:)  = yhat(nl+1:end,:);
        % forecast
        fore = NaN(fhor+nl,nvar);
        fore(1:2,:) = Y(end-1:end,:);
        for ff = nl+1:fhor+nl
            reg        = [1 fore(ff-1,:) fore(ff-2,:)]; % not automised yet!
            fore(ff,:) = reg*reshape(b,nb/nvar,nvar)  ...
                + randn(1,nvar)*chol(Sig);
        end
        fdraw(ii-nburn,:,:) = fore(nl+1:end,:);
    end
    waitbar(ii/(ndraw+nburn));
end

close(wb)


%% Plot IRFs
TT = 1:hor-nl;
pc = prctile(irfs,[50, 16, 84],1);
figure('name','Impulse responses to structural shock')
for pp = 1:numel(pnam)
    subplot(2,2,pp)
    plot(TT,pc(1,:,pp),'b',TT,pc(2,:,pp),'b--',TT,pc(3,:,pp),'b--');
    hold on;
    plot(TT,zeros(hor-nl,1),'r')
    title(pnam{pp})
    axis tight
    if pp==2; legend('50%','16/84%','Location','SouthEast'); end
end


%% Plot forecast
figure('name','Forecast of the variables')
for pp = 1:numel(pnam)
    fc = prctile(squeeze(fdraw(:,:,pp)),[5 16.7 50 83.3 95],1)';
    Yp = [repmat(Y(:,pp),1,size(fc,2)); fc];
    if strcmp(choose_example,'ex2.2')
        subplot(2,2,pp)
        plot(tim,Yp)
        xlim([2007+5/12 2013])
    elseif strcmp(choose_example,'ex2.1')
        subplot(1,2,pp)
        plot(tim,Yp)
        xlim([1995 2015])
    end
    title(pnam{pp})
end
