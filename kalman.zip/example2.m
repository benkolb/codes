
% Example 2: Code to get Kalman filter estimates of 
% Taylor rule coefficients for US data, 85Q1-08Q2
% This code is available under 
% http://www.bkolb.eu/codes/kalman_filter
% by Benedikt Kolb, March 2015

%% Housekeeping
clear all; clc; 

%% Load data (quarterly US data from 1954Q3 to 2014Q4, linearly detrended)
data = csvread('TR_US_data.csv',1,1);
% only use data after 1982Q1 to 2007Q2
Y = data(110:end-30,1);  % real GDP growth rate
P = data(110:end-30,2);  % GDP deflator, percentage growth
R = data(110:end-30,3); % Federal funds rate
Z = [Y P]; % regressors (here: KF coefficients!)

%% Initialise components for Kalman filter
T = size(R,1);  % sample size
time = linspace(1982.0,2007.25,T)'; % for plotting

%% Grid search
ngri = 10; % gridsize
grid = linspace(log(0.000001),log(0.01),ngri);
grid = exp(grid);

likd = zeros(ngri,ngri,ngri); % collects likelihoods
betas = NaN(ngri,ngri,ngri,size(Z,2),T); % collects coefficients

% initial guess for Sigma
Sigma0=[1 0
        0 1];
% alternatively (comment out for initialising Sigma by Lyapunov equation):
% Sigma0 = lyapunov_symm(A,Q,1); % requires Dynare's lyapunov_symm.m

A = eye(2);

% start gridsearch
for iy=1:ngri
    disp(iy)
    for ip=1:ngri
        for ie=1:ngri
            Q = [iy, 0; 0, ip];
            [likd(iy,ip,ie) betas(iy,ip,ie,:,:) SIGG] =...
                            kalmanf_xt(R,A,Q,Z,ie,Sigma0);
        end
    end
end
likd(isreal(likd)==0) = Inf; % sort out imaginary likelihoods
[val pos] = min(likd(:));
[a b c] = ind2sub(size(likd),pos);
para_min  = [grid(a) grid(b) grid(c)];


%% Plots and display of results
figure('name','KF results')
subplot(2,1,1)
g=plot(time,squeeze(betas(a,b,c,2,:))',...
    time,squeeze(betas(a,b,c,1,:))');
set(g(1),'linewidth',2);
% set(h(2),'linewidth',1);
legend('\beta_{\pi,t}','\beta_{y,t}')
title('Taylor rule coefficients')
subplot(2,1,2)
h=plot(time,R,time,Z(:,1),time,Z(:,2),'-.');
set(h(1),'linewidth',2);
legend('R_t','Y_t','\Pi_t')
title('Time series used')

disp('Mean of beta_y and beta_p:')
disp(mean(squeeze(betas(a,b,c,:,:)),2)')
