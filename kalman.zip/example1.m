
% Example 1: Code to maximise likelihood of a New 
% Keynesian model with a financial accelerator over 
% one parameter to illustrate the use of the Kalman 
% filter. 
% This code is available under 
% http://www.bkolb.eu/codes/kalman_filter
% by Benedikt Kolb, April 2015

clear all; clc;

%% Load data, write data vector and the model's var-cov matrix
dat   = open('dat_full.mat'); % data come as [Y C I P R S]
dy    = dat.dy;
% Theta gives the parameters; their meaning does not matter here.
Theta = [0.99,0.9728,0.025,0.75,2,1.5,0.125,0.5,0.3,0.9,0.5,0.5,0.5, ...
         0.5,0.5,0.0625,0.0625,0.0625,0.0625,0.0625,0.0625];
Sigma = diag([Theta(16),...  % technology shock
              Theta(17),...  % monetary policy shock
              Theta(18),...  % gvt spending shock
              Theta(19),...  % preference shock
              Theta(20),...  % shock to financial accelerator
              Theta(21)]);   % xi


%% Let Uhlig solve your model
[PP,QQ,~,~,NN,PROBLEM] = uhligsolve(Theta); % as in Uhlig (1999)
if PROBLEM==1 %  if 1, there's a problem for Uhlig to find solution
    L=-Inf;
    return;
end

%% Prepare Kalman filter
[~,nd] = size(dy);
ns = size(PP,1) + size(NN,1);

R = eye(6)*0.5; % assume intermediate measurement error

% Map observables from dy into transition equation
M       = zeros(nd,ns);
M(1,5)  = 1; % Y = y(t)
M(2,6)  = 1; % C = c(t)
M(3,7)  = 1; % I = i(t)
M(4,8)  = 1; % P = pi(t)
M(5,9)  = 1; % R = rn(t)
M(6,10) = 1; % S = cs(t)

F      = [PP QQ*NN; zeros(size(NN,1),size(PP,2)) NN];
G      = [QQ*Sigma; Sigma];

% Initial value for model likelihood
[L xx] = kalmanf(dy,F,G,M,R);
disp('Initial value for model likelihood')
disp(L)

%% Grid search for "optimal" elasticity phi (8th entry of Theta vector)
ngri = 10; % gridsize
grid = linspace(.95,.99,ngri);
L    = NaN(10,1);

for phi = 1:ngri
    Theta(2) = grid(phi);
    [PP,QQ,~,~,NN,PROBLEM] = uhligsolve(Theta); % as in Uhlig (1999)
    if PROBLEM==1 %  if 1, there's a problem for Uhlig to find solution
        L=-Inf;
        return;
    end
    
    % prepare Kalman filter
    Fl      = [PP QQ*NN; zeros(size(NN,1),size(PP,2)) NN];
    Gl      = [QQ*Sigma; Sigma];
    
    % obtain model likelihood
    [L(phi) xx] = kalmanf(dy,Fl,Gl,M,R);
end

% likd(isreal(likd)==0) = Inf; % sort out imaginary likelihoods
[val pos] = max(L(:));
pos = ind2sub(size(L),pos);

disp('Value of phi that maximises likelihood:')
disp(grid(pos))
disp('Maximised likelihood:')
disp(L(pos))
    